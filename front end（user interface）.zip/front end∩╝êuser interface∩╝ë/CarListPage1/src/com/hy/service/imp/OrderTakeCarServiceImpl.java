package com.hy.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.OrderTakeCarMapper;
import com.hy.model.OrderTakeCar;
import com.hy.service.IOrderTakeCarService;

/**
 * ҵ���߼���ʵ������
 * @author Administrator
 *
 */
@Service
public class OrderTakeCarServiceImpl implements IOrderTakeCarService {

	@Autowired
	private OrderTakeCarMapper orderTakeCarMapper;
	
	@Transactional
	@Override
	public List<OrderTakeCar> findAll() {		
		return orderTakeCarMapper.findAll();
	}
	
	/*
	 * insert
	 * @see com.cissst.software.service.IUserService#addUser(com.cissst.software.model.User)
	 */
	@Override
	public void addOrderTakeCar(OrderTakeCar orderTakeCar) {
		orderTakeCarMapper.addOrderTakeCar(orderTakeCar);
	}
	
	/*
	 * select_One
	 * @see com.cissst.software.service.IUserService#findUserById(int)
	 */
	@Override
	public OrderTakeCar findOrderTakeCarByOrderNo(String order_no) {
		return orderTakeCarMapper.findOrderTakeCarByOrderNo(order_no);
	}
	/*
	 * delete
	 * @see com.cissst.software.service.IUserService#deleteUserById(int)
	 */
	@Override
	public void deleteOrderTakeCarByOrderNo(String order_no) {
		orderTakeCarMapper.deleteOrderTakeCarByOrderNo(order_no);
	}

}
