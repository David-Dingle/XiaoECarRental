package com.hy.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CompanyMapper;
import com.hy.model.Company;
import com.hy.model.CompanyCar;
import com.hy.model.Order;
import com.hy.model.OrderCar;
import com.hy.model.OrderTakeCar;
import com.hy.service.ICompanyService;

/**
 * ҵ���߼���ʵ������
 *
 */
@Service
public class CompanyServiceImpl implements ICompanyService{
	
	@Autowired
	private CompanyMapper companymapper;
	
	@Transactional
	@Override
	public List<Company> findAll(){
		return companymapper.findAll();
	}
	
	//��ѯ���д����⳵��˾�ĳ���
	@Override
	public List<String> findAddress(){
		return companymapper.findAddress();
	};
	
	//����lease_id��car_name��ѯ������Ϣ
	@Override
	public CompanyCar findCar(String car_no){
		return companymapper.findCar(car_no);
	}
	
	@Override
	public List<Company> findCompanyByAddress(String address){
		return companymapper.findCompanyByAddress(address);
	}
	
	@Override
	public List<Company> findAllCarByCompanyCar(){
		return companymapper.findAllCarByCompanyCar();
	}
			
	//����Order��
	public void addOrder(Order order){
		companymapper.addOrder(order);
	}
			
	//����OrderCar��
	public void addOrderCar(OrderCar orderCar){
		companymapper.addOrderCar(orderCar);
	}
			
	//����OrderTakeCar��
	public void addOrderTakeCar(OrderTakeCar orderTakeCar){
		companymapper.addOrderTakeCar(orderTakeCar);
	}
}
