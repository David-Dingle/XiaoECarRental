package com.hy.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CompanyCarMapper;
import com.hy.model.CompanyCar;
import com.hy.service.ICompanyCarService;

@Service
public class CompanyCarServiceImpl implements ICompanyCarService{

	@Autowired
	private CompanyCarMapper companyCarMapper;
	
	@Transactional
	@Override
	public CompanyCar findCompanyCarById(int id) {
		return companyCarMapper.findCompanyCarById(id);
	}
	
}
