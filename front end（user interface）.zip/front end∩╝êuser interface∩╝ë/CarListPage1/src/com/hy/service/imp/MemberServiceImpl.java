package com.hy.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.MemberMapper;
import com.hy.model.Member;
import com.hy.service.MemberService;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberMapper mapper;
	
	@Transactional
	@Override
	public void addMember(Member member) {
		mapper.addMember(member);
	}

	@Override
	public void deleteMember(int id) {
		mapper.deleteMember(id);
	}

	@Override
	public void updateMember(Member member) {
		mapper.updateMember(member);
	}

	@Override
	public List<Member> checkMemberById(int id) {
		return mapper.checkMemberById(id);
	}

	@Override
	public List<Member> searchMember(String keyword,String level) {
		return mapper.searchMember(keyword,level);
	}

	@Override
	public List<Member> checkAllMember() {
		return mapper.checkAllMember();
	}
	
	@Override
	public Member validation(String login_name,String password) {
		return mapper.validation(login_name,password);
	}

}
