package com.hy.service.imp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CarListMapper;
import com.hy.model.CompanyCar;
import com.hy.service.ICarListService;

@Service
public class CarListServiceImp implements ICarListService{
	
	@Autowired
	private CarListMapper carListMapper;
	
	@Transactional
    public List<String> findAllBrand() {
    	return carListMapper.findAllBrand();
    }
	
	public List<String> findSubSerial(String brandName) {
		return carListMapper.findSubSerial(brandName);
	}
	
	public List<CompanyCar> findSubCars(String serialName) {
		return  carListMapper.findSubCars(serialName);
	}
}
