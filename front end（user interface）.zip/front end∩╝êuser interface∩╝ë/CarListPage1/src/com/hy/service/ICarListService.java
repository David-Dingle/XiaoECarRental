package com.hy.service;

import java.util.List;

import com.hy.model.CompanyCar;

public interface ICarListService {

	public List<String> findAllBrand();
	
	public List<String> findSubSerial(String brandName);
	
	public List<CompanyCar> findSubCars(String serialName);
}
