package com.hy.service;

import com.hy.model.CompanyCar;

public interface ICompanyCarService {
	public CompanyCar findCompanyCarById(int id);
}
