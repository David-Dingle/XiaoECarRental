package com.hy.mapper;

import java.util.List;

import com.hy.model.Member;

public interface MemberMapper {
	public void addMember(Member member);
	
	public void deleteMember(int id);
	
	public void updateMember(Member member);
	
	public List<Member> checkMemberById(int id);
	
	public List<Member> checkAllMember();
	
	public List<Member> searchMember(String keyword,String level);
	
	public Member validation(String login_name,String password);
}
