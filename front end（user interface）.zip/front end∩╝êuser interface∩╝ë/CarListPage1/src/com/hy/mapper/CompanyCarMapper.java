package com.hy.mapper;

import com.hy.model.CompanyCar;

public interface CompanyCarMapper {

	public CompanyCar findCompanyCarById(int id);
}
