package com.hy.mapper;

import java.util.List;

import com.hy.model.CompanyCar;

public interface CarListMapper {
	
	public List<String> findAllBrand();
	
	public List<String> findSubSerial(String brandName);
	
	public List<CompanyCar> findSubCars(String serialName);
	
}
