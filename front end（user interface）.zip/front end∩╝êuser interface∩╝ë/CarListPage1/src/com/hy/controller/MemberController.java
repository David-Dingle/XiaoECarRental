package com.hy.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.hy.model.Member;

import com.hy.service.MemberService;

@Controller
@RequestMapping("/Member")
public class MemberController {
	@Autowired
	private MemberService ms;
	
	
	
	@RequestMapping("/add")
	@ResponseBody
	public Boolean addMember(HttpServletRequest req, HttpServletResponse res) {
		String mobile1 = req.getParameter("mobile1");
		String password1 = req.getParameter("password1");
		String username1 = req.getParameter("username1");
		Member mem = new Member();
		mem.setMember_name(username1);
		mem.setLogin_name(mobile1);
		mem.setMember_pwd(password1);
		mem.setMobile_phone(mobile1);
		ms.addMember(mem);
		return true;
	}
	
	@RequestMapping("/login")
	@ResponseBody
	public String selectMember(HttpServletRequest req, HttpServletResponse res) {
		String mobile2 = req.getParameter("mobile2");
		String password2 = req.getParameter("password2");
		System.out.println(password2);
		System.out.println(mobile2);
		Member member = null;
		member = ms.validation(mobile2, password2);
		if(member != null) {
			HttpSession session = req.getSession();
			session.setAttribute("member_name", member.getMember_name());
			return member.getMember_name();
		}
		else {
			return null;
		}
	}
	
	@RequestMapping("/checkmember")
	@ResponseBody
	public String checkMember(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		String message = null;
		message = (String)session.getAttribute("member_name");
		if(message != null) {
			return message;
		}
		return "nobody";
	}
	
	@RequestMapping("/outer")
	@ResponseBody
	public String Memberout(HttpServletRequest req, HttpServletResponse res) {
		HttpSession session = req.getSession();
		session.setAttribute("member_name", null);
		return "ok";
	}
	
}
