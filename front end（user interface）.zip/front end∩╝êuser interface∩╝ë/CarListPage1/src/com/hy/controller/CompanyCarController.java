package com.hy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hy.model.CompanyCar;
import com.hy.service.ICompanyCarService;

/**
 * 
 * @author david
 *
 */
@Controller
@RequestMapping("/CompanyCar")
public class CompanyCarController {
	
	//此处需要补充注解
	@Autowired
	private ICompanyCarService companyCarService;
	/**
	 * 
	 * @param company_Car
	 * @return
	 */
	@RequestMapping("/findById/{id}")
	public String findCompanyCarById(@PathVariable int id, Model model) {
		CompanyCar companyCar = companyCarService.findCompanyCarById(id);
		model.addAttribute("CompanyCar", companyCar);
		return "forward:/car_info.jsp";
	}
	
	
}
