package com.hy.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hy.model.Company;
import com.hy.model.CompanyCar;
import com.hy.model.Order;
import com.hy.model.OrderCar;
import com.hy.model.OrderCarS;
import com.hy.model.OrderTakeCar;
import com.hy.service.ICompanyService;
import com.sun.corba.se.impl.activation.ORBD;


/**
 * ǰ�˿�������--ʵ�ֹ�˾��Ϣ����
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/company")
public class CompanyController {
	
	@Autowired
	private ICompanyService companyService;

	/**
	 * ��ѯ����
	 * @param model
	 * @return
	 */
	@RequestMapping("/findall")
	public String findAll(Model model){
		List<Company> companys = companyService.findAll();
		model.addAttribute("companys", companys);
		return "forward:/index.jsp";
	}
	//��ѯ���д����⳵��˾�ĳ���
	@RequestMapping("/findaddress")
	public String findAddress(Model model){
		List<String> companys = companyService.findAddress();
		model.addAttribute("companys", companys);
		return "forward:/index.jsp";
	}
	
	@RequestMapping("/findonebyaddress/{address}")
	public String findCompanyByAddress(Model model, @PathVariable String address){
		List<Company> companys = companyService.findCompanyByAddress(address);
		model.addAttribute("companys", companys);
		return "forward:/";
	}
	
	@RequestMapping("/findallcarbycompanycar")
	public String findAllCarByCompanyCar(Model model){
		List<Company> companycars = companyService.findAllCarByCompanyCar();
		model.addAttribute("companycars", companycars);
		return "forward:/index.jsp";
	}
	
	//ͨ���첽������ȡt_company_car��
	@RequestMapping("/ajax")
	@ResponseBody
	public List<Company> getCompanyCarList(Model model){
		List<Company> companycars = companyService.findAllCarByCompanyCar();
		model.addAttribute(companycars);
		return companycars;
	}
	//ͨ���첽������ȡaddress
	@RequestMapping("/ajaxa")
	@ResponseBody
	public List<String> getAddress(Model model){
		List<String> addresses = companyService.findAddress();
		model.addAttribute(addresses);
		return addresses;
	}
	//ͨ���첽������ȡCompany
	@RequestMapping("/ajaxc")
	@ResponseBody
	public List<Company> getAddress(Model model, HttpServletRequest request){
		String address = request.getParameter("address");
		List<Company> companys = companyService.findCompanyByAddress(address);
		model.addAttribute("companys",companys);
		return companys;
	}
	//����car_no��ȡ������Ϣ
	@RequestMapping("/cars/{carno}")
	public String findCar(Model model, @PathVariable String carno){
		CompanyCar car = companyService.findCar(carno);
		model.addAttribute("car", car);
		return "forward:/infor.jsp";
	}
	
	
	//ת��������Ϣ
	@RequestMapping("/order")
	public String findAllOrder(OrderCarS ord, Model model){
		model.addAttribute("orders", ord);
		System.out.println("ord:"+ord);
		return "forward:/order_list.jsp";
	}
	//���Ӽ�¼
	@RequestMapping("/add")
	public String addOrder(OrderCarS ord, Model model){
		//����Order��
		Order order = new Order();
		order.setOrder_no(ord.order_no);
		order.setRental_fee(ord.rental_fee);
		order.setInsurance_fee(ord.insurance_fee);
		order.setDeposit_fee(ord.deposit_fee);
		order.setIllegal_fee(ord.illegal_fee);
		order.setPay_fee(ord.pay_fee);
		companyService.addOrder(order);
		
		//����OrderCar��
		OrderCar orderCar = new OrderCar();
		orderCar.setOrder_no(ord.order_no);
		orderCar.setTack_address(ord.tack_address);
		orderCar.setReturn_address(ord.return_address);
		orderCar.setLease_id(ord.lease_id);
		orderCar.setDisplacement(ord.displacement);
		orderCar.setSeating(ord.seating);
		orderCar.setGear(ord.gear);
		orderCar.setCar_no(ord.car_no);
		orderCar.setCar_pic(ord.car_pic);
		orderCar.setCar_type(ord.car_type);
		orderCar.setCar_name(ord.car_name);
		companyService.addOrderCar(orderCar);
		
		//����OrderTakeCar��
		OrderTakeCar orderTakeCar = new OrderTakeCar();
		//order_no, user_real_name, user_phone, user_idcard, take_date, return_date
		orderTakeCar.setOrder_no(ord.order_no);
		orderTakeCar.setUser_real_name(ord.user_real_name);
		orderTakeCar.setUser_phone(ord.user_phone);
		orderTakeCar.setUser_idcard(ord.user_idcard);
		orderTakeCar.setTake_date(ord.order_start_time);
		orderTakeCar.setReturn_date(ord.order_end_time);
		
		return "forward:/index.jsp";
	}
}
