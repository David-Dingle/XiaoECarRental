package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hy.model.OrderTakeCar;
import com.hy.service.IOrderTakeCarService;

/**
 * ǰ�˿�������--ʵ���û���Ϣ����
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/ordertakecar")
public class OrderTakeCarController {

	@Autowired
	private IOrderTakeCarService orderTakeCarService;
	
	/**
	 * ���Ӳ���
	 * @param festival
	 * @return
	 */
	@RequestMapping("/add")
	public String addOrderTakeCar(OrderTakeCar orderTakeCar){
		orderTakeCarService.addOrderTakeCar(orderTakeCar);
		return "redirect:/";
	}
	
	/**
	 * ��ѯ����
	 * @param model
	 * @return
	 */
	@RequestMapping("/findall")
	public String findAll(Model model){
		List<OrderTakeCar> orders = orderTakeCarService.findAll();
		model.addAttribute("orders", orders);
		return "forward:/";
	}
	
	@RequestMapping("/findone/{order_no}")
	public String findOne(@PathVariable String order_no){
		OrderTakeCar order = orderTakeCarService.findOrderTakeCarByOrderNo(order_no);
		
		return "forward:/";
	}
	
	@RequestMapping("/delete/{model}/{order_no}")
	public String deleteOrderTakeCar(Model model ,@PathVariable String order_no){
		orderTakeCarService.deleteOrderTakeCarByOrderNo(order_no);
		return "redirect:/";
	}
	
}
