package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hy.model.CompanyCar;
import com.hy.service.ICarListService;
/**
 * 
 * @author david
 *
 */
@Controller
@RequestMapping("/carlist")
public class CarListController {
	
	@Autowired
	private ICarListService carListService;
	
	@RequestMapping("/findallbrand")
	public String findAllBrand(Model model) {
		List<String> brands = carListService.findAllBrand();
		model.addAttribute("brand", brands);
    	return "forward:/car_list.jsp";
    }
	
	@RequestMapping("/findSubSerial")
    @ResponseBody
    public List<String> testAjax5(String brandname, Model model){
        List<String> serial = carListService.findSubSerial(brandname);
        return serial;
    }
	
	@RequestMapping("/findSubCar")
    @ResponseBody
    public List<CompanyCar> testAjax6(String serialname, Model model){
		String nname = "%"+serialname+"%";
		List<CompanyCar> cars = carListService.findSubCars(nname);
        return cars;
    }
	
	
}
