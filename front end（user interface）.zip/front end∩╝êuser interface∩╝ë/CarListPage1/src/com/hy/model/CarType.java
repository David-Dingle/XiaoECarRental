package com.hy.model;

import java.util.Date;

public class CarType {

	private int id;
	private String car_type_code;
	private String car_type_name;
	private Date create_date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCar_type_code() {
		return car_type_code;
	}
	public void setCar_type_code(String car_type_code) {
		this.car_type_code = car_type_code;
	}
	public String getCar_type_name() {
		return car_type_name;
	}
	public void setCar_type_name(String car_type_name) {
		this.car_type_name = car_type_name;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	
	
}
