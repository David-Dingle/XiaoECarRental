package com.hy.model;

import java.util.Date;

public class OrderCarS {
	public double rental_fee;//�⳵��
	public double insurance_fee;//���շ�
	public double deposit_fee;//��������Ѻ��
	public double illegal_fee;//����Υ��Ѻ��
	public double pay_fee;//����Ӧ�����
	public int rent_days;//����
	public String order_no;//������
	public String user_real_name;
	public String user_idcard;
	public String user_phone;
	public String order_start_time;
	public String order_end_time;
	public String tack_address;
	public String return_address;
	public String car_name;
	public String car_pic;
	public String car_type;
	public String car_no;
	public String displacement;
	public int lease_id;
	public int seating;
	public String gear;
	public double getRental_fee() {
		return rental_fee;
	}
	public void setRental_fee(double rental_fee) {
		this.rental_fee = rental_fee;
	}
	public double getInsurance_fee() {
		return insurance_fee;
	}
	public void setInsurance_fee(double insurance_fee) {
		this.insurance_fee = insurance_fee;
	}
	public double getDeposit_fee() {
		return deposit_fee;
	}
	public void setDeposit_fee(double deposit_fee) {
		this.deposit_fee = deposit_fee;
	}
	public double getIllegal_fee() {
		return illegal_fee;
	}
	public void setIllegal_fee(double illegal_fee) {
		this.illegal_fee = illegal_fee;
	}
	public double getPay_fee() {
		return pay_fee;
	}
	public void setPay_fee(double pay_fee) {
		this.pay_fee = pay_fee;
	}
	public int getRent_days() {
		return rent_days;
	}
	public void setRent_days(int rent_days) {
		this.rent_days = rent_days;
	}
	public String getOrder_no() {
		return order_no;
	}
	public void setOrder_no(String order_no) {
		this.order_no = order_no;
	}
	public String getUser_real_name() {
		return user_real_name;
	}
	public void setUser_real_name(String user_real_name) {
		this.user_real_name = user_real_name;
	}
	public String getUser_idcard() {
		return user_idcard;
	}
	public void setUser_idcard(String user_idcard) {
		this.user_idcard = user_idcard;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	
	public String getOrder_start_time() {
		return order_start_time;
	}
	public void setOrder_start_time(String order_start_time) {
		this.order_start_time = order_start_time;
	}
	public String getOrder_end_time() {
		return order_end_time;
	}
	public void setOrder_end_time(String order_end_time) {
		this.order_end_time = order_end_time;
	}
	public String getTack_address() {
		return tack_address;
	}
	public void setTack_address(String tack_address) {
		this.tack_address = tack_address;
	}
	public String getReturn_address() {
		return return_address;
	}
	public void setReturn_address(String return_address) {
		this.return_address = return_address;
	}
	public String getCar_name() {
		return car_name;
	}
	public void setCar_name(String car_name) {
		this.car_name = car_name;
	}
	public String getCar_pic() {
		return car_pic;
	}
	public void setCar_pic(String car_pic) {
		this.car_pic = car_pic;
	}
	public String getCar_type() {
		return car_type;
	}
	public void setCar_type(String car_type) {
		this.car_type = car_type;
	}
	public String getCar_no() {
		return car_no;
	}
	public void setCar_no(String car_no) {
		this.car_no = car_no;
	}
	public String getDisplacement() {
		return displacement;
	}
	public void setDisplacement(String displacement) {
		this.displacement = displacement;
	}
	public int getLease_id() {
		return lease_id;
	}
	public void setLease_id(int lease_id) {
		this.lease_id = lease_id;
	}
	public int getSeating() {
		return seating;
	}
	public void setSeating(int seating) {
		this.seating = seating;
	}
	public String getGear() {
		return gear;
	}
	public void setGear(String gear) {
		this.gear = gear;
	}
	@Override
	public String toString() {
		return "OrderCarS [rental_fee=" + rental_fee + ", insurance_fee=" + insurance_fee + ", deposit_fee="
				+ deposit_fee + ", illegal_fee=" + illegal_fee + ", pay_fee=" + pay_fee + ", rent_days=" + rent_days
				+ ", order_no=" + order_no + ", user_real_name=" + user_real_name + ", user_idcard=" + user_idcard
				+ ", user_phone=" + user_phone + ", order_start_time=" + order_start_time + ", order_end_time="
				+ order_end_time + ", tack_address=" + tack_address + ", return_address=" + return_address
				+ ", car_name=" + car_name + ", car_pic=" + car_pic + ", car_type=" + car_type + ", car_no=" + car_no
				+ ", displacement=" + displacement + ", lease_id=" + lease_id + ", seating=" + seating + ", gear="
				+ gear + ", getRental_fee()=" + getRental_fee() + ", getInsurance_fee()=" + getInsurance_fee()
				+ ", getDeposit_fee()=" + getDeposit_fee() + ", getIllegal_fee()=" + getIllegal_fee()
				+ ", getPay_fee()=" + getPay_fee() + ", getRent_days()=" + getRent_days() + ", getOrder_no()="
				+ getOrder_no() + ", getUser_real_name()=" + getUser_real_name() + ", getUser_idcard()="
				+ getUser_idcard() + ", getUser_phone()=" + getUser_phone() + ", getOrder_start_time()="
				+ getOrder_start_time() + ", getOrder_end_time()=" + getOrder_end_time() + ", getTack_address()="
				+ getTack_address() + ", getReturn_address()=" + getReturn_address() + ", getCar_name()="
				+ getCar_name() + ", getCar_pic()=" + getCar_pic() + ", getCar_type()=" + getCar_type()
				+ ", getCar_no()=" + getCar_no() + ", getDisplacement()=" + getDisplacement() + ", getLease_id()="
				+ getLease_id() + ", getSeating()=" + getSeating() + ", getGear()=" + getGear() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
}
