package com.hy.model;

import java.util.Date;

public class Order {
		int id;
		String order_no;
		private Company company;
		double rental_fee;//�⳵��
		double insurance_fee;//���շ�
		double deposit_fee;//��������Ѻ��
		double illegal_fee;//����Υ��Ѻ��
		double coupons_fee;//����ȯ���ý��
		double factorage_fee;//����������
		double emptDrive_fee;//�����ռ�ʻ��
		double activity_fee;//������Żݷ�
		double pay_fee;//����Ӧ�����
		int pay_type;//���ʽ
		int pay_company;//֧��ƽ̨
		Date pay_time;//֧��ʱ��
		int base_state;//��������״̬
		int pay_state;//����֧��״̬
		int take_state;//ȡ��״̬
		Date create_time;//��������ʱ��
		int delete_state;//ɾ��״̬
		String menber_message;//�������
		String member_nick;//����ǳ�
		String canceled_message;//����ȡ��ԭ��
		String canceled_time;//ȡ��ʱ��
		int isrelet;//�Ƿ���Լ0F,1Y
		String reletOrde;//���ⵥ��
		String sourcOrder;//ԭ����
		int need_incoice;//�Ƿ���Ҫ��Ʊ0:����Ҫ 1:��Ҫ
		double overtime_charge;//��ʱ��
		String handler;//������
		String refuse_time;//
		String receipt;//�վ�
		String reason;//�⳵ԭ��
		String plate_number;//���ƺ�
		String voucher_fee;//ƾ֤��
	

		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getOrder_no() {
			return order_no;
		}
		public void setOrder_no(String order_no) {
			this.order_no = order_no;
		}
		

		public Company getCompany() {
			return company;
		}
		public void setCompany(Company company) {
			this.company = company;
		}
		public double getRental_fee() {
			return rental_fee;
		}
		public void setRental_fee(double rental_fee) {
			this.rental_fee = rental_fee;
		}
		public double getInsurance_fee() {
			return insurance_fee;
		}
		public void setInsurance_fee(double insurance_fee) {
			this.insurance_fee = insurance_fee;
		}
		public double getDeposit_fee() {
			return deposit_fee;
		}
		public void setDeposit_fee(double deposit_fee) {
			this.deposit_fee = deposit_fee;
		}
		public double getIllegal_fee() {
			return illegal_fee;
		}
		public void setIllegal_fee(double illegal_fee) {
			this.illegal_fee = illegal_fee;
		}
		public double getCoupons_fee() {
			return coupons_fee;
		}
		public void setCoupons_fee(double coupons_fee) {
			this.coupons_fee = coupons_fee;
		}
		public double getFactorage_fee() {
			return factorage_fee;
		}
		public void setFactorage_fee(double factorage_fee) {
			this.factorage_fee = factorage_fee;
		}
		public double getEmptDrive_fee() {
			return emptDrive_fee;
		}
		public void setEmptDrive_fee(double emptDrive_fee) {
			this.emptDrive_fee = emptDrive_fee;
		}
		public double getActivity_fee() {
			return activity_fee;
		}
		public void setActivity_fee(double activity_fee) {
			this.activity_fee = activity_fee;
		}
		public double getPay_fee() {
			return pay_fee;
		}
		public void setPay_fee(double pay_fee) {
			this.pay_fee = pay_fee;
		}
		public int getPay_type() {
			return pay_type;
		}
		public void setPay_type(int pay_type) {
			this.pay_type = pay_type;
		}
		public int getPay_company() {
			return pay_company;
		}
		public void setPay_company(int pay_company) {
			this.pay_company = pay_company;
		}
		
		public Date getPay_time() {
			return pay_time;
		}
		public void setPay_time(Date pay_time) {
			this.pay_time = pay_time;
		}
		public int getBase_state() {
			return base_state;
		}
		public void setBase_state(int base_state) {
			this.base_state = base_state;
		}
		public int getPay_state() {
			return pay_state;
		}
		public void setPay_state(int pay_state) {
			this.pay_state = pay_state;
		}
		public int getTake_state() {
			return take_state;
		}
		public void setTake_state(int take_state) {
			this.take_state = take_state;
		}
		
		public Date getCreate_time() {
			return create_time;
		}
		public void setCreate_time(Date create_time) {
			this.create_time = create_time;
		}
		public int getDelete_state() {
			return delete_state;
		}
		public void setDelete_state(int delete_state) {
			this.delete_state = delete_state;
		}
		public String getMenber_message() {
			return menber_message;
		}
		public void setMenber_message(String menber_message) {
			this.menber_message = menber_message;
		}
		public String getMember_nick() {
			return member_nick;
		}
		public void setMember_nick(String member_nick) {
			this.member_nick = member_nick;
		}
		public String getCanceled_message() {
			return canceled_message;
		}
		public void setCanceled_message(String canceled_message) {
			this.canceled_message = canceled_message;
		}
		public String getCanceled_time() {
			return canceled_time;
		}
		public void setCanceled_time(String canceled_time) {
			this.canceled_time = canceled_time;
		}
		public int getIsrelet() {
			return isrelet;
		}
		public void setIsrelet(int isrelet) {
			this.isrelet = isrelet;
		}
		public String getReletOrde() {
			return reletOrde;
		}
		public void setReletOrde(String reletOrde) {
			this.reletOrde = reletOrde;
		}
		public String getSourcOrder() {
			return sourcOrder;
		}
		public void setSourcOrder(String sourcOrder) {
			this.sourcOrder = sourcOrder;
		}
		public int getNeed_incoice() {
			return need_incoice;
		}
		public void setNeed_incoice(int need_incoice) {
			this.need_incoice = need_incoice;
		}
		public double getOvertime_charge() {
			return overtime_charge;
		}
		public void setOvertime_charge(double overtime_charge) {
			this.overtime_charge = overtime_charge;
		}
		public String getHandler() {
			return handler;
		}
		public void setHandler(String handler) {
			this.handler = handler;
		}
		public String getRefuse_time() {
			return refuse_time;
		}
		public void setRefuse_time(String refuse_time) {
			this.refuse_time = refuse_time;
		}
		public String getReceipt() {
			return receipt;
		}
		public void setReceipt(String receipt) {
			this.receipt = receipt;
		}
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
		}
		public String getPlate_number() {
			return plate_number;
		}
		public void setPlate_number(String plate_number) {
			this.plate_number = plate_number;
		}
		public String getVoucher_fee() {
			return voucher_fee;
		}
		public void setVoucher_fee(String voucher_fee) {
			this.voucher_fee = voucher_fee;
		}
		
	}
