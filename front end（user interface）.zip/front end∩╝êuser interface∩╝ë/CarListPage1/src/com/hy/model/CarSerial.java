package com.hy.model;

import java.util.Date;

public class CarSerial {
	private int id;
	private String brand_code,
	SERIAL_CODE,
	SERIAL_NAME;
	private Date create_date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getSERIAL_CODE() {
		return SERIAL_CODE;
	}
	public void setSERIAL_CODE(String sERIAL_CODE) {
		SERIAL_CODE = sERIAL_CODE;
	}
	public String getSERIAL_NAME() {
		return SERIAL_NAME;
	}
	public void setSERIAL_NAME(String sERIAL_NAME) {
		SERIAL_NAME = sERIAL_NAME;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	@Override
	public String toString() {
		return "CarSerial [id=" + id + ", brand_code=" + brand_code + ", SERIAL_CODE=" + SERIAL_CODE + ", SERIAL_NAME="
				+ SERIAL_NAME + ", create_date=" + create_date + "]";
	}
}
