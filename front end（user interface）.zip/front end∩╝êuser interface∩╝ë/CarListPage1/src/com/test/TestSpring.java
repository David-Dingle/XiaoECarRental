package com.test;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hy.model.CompanyCar;
import com.hy.service.ICarListService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:WebContent/WEB-INF/spring-core-config.xml")
public class TestSpring {
	@Autowired
	private ICarListService carListService;

	@Test
	public void testMethod1(){
		List<String> brands = carListService.findAllBrand();
		for(String brandName : brands){
			System.out.println(brandName);
		}
	}
	
	@Test
	public void test2() {
		String serialName = "%奥迪A6L%";
		List<CompanyCar> cars = carListService.findSubCars(serialName);
		for(CompanyCar car : cars) {
			System.out.println(car);
		}
	}
}
