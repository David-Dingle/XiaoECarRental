/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 50022
Source Host           : 127.0.0.1:3306
Source Database       : mydata

Target Server Type    : MYSQL
Target Server Version : 50022
File Encoding         : 65001

Date: 2018-07-20 09:51:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for car_type
-- ----------------------------
DROP TABLE IF EXISTS `car_type`;
CREATE TABLE `car_type` (
  `id` int(5) NOT NULL,
  `brand_id` int(5) default NULL,
  `type_id` int(5) default NULL,
  `name` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car_type
-- ----------------------------
INSERT INTO `car_type` VALUES ('3', '1003', '1004', 'C系');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user` (
  `userid` int(10) default NULL,
  `username` varchar(20) default NULL,
  `useremail` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES ('1', '比利', '163@qq.com');

-- ----------------------------
-- Table structure for t_authority_resources
-- ----------------------------
DROP TABLE IF EXISTS `t_authority_resources`;
CREATE TABLE `t_authority_resources` (
  `ID` varchar(32) NOT NULL COMMENT 'id',
  `MENU_NAME` varchar(50) default NULL COMMENT 'menu_name',
  `MENU_URL` varchar(500) default NULL COMMENT 'memu_url',
  `T_NO` varchar(40) default NULL COMMENT 'no',
  `T_STRUCTURE` varchar(20) default NULL COMMENT 'structure',
  `REMARK` varchar(50) default NULL COMMENT 'remark',
  `SORT` decimal(8,0) default NULL COMMENT 'sort',
  `T_TYPE` varchar(1) default NULL COMMENT 'type 0èœå• 1åŠŸèƒ½ç‚¹',
  `ISLEAF` varchar(1) default NULL COMMENT '0å¶å­èŠ‚ç‚¹ 1æžèŠ‚ç‚¹',
  `ISSHOW` varchar(1) default '1' COMMENT 'æ˜¯å¦æ˜¾ç¤ºï¼Œé»˜è®¤1æ˜¯',
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='èœå•èµ„æº';

-- ----------------------------
-- Records of t_authority_resources
-- ----------------------------
INSERT INTO `t_authority_resources` VALUES ('0', '权限资源目录', 'null', '1', 'root', '权限资源目录', '1', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('027f6c0a06154810bbed8de90c9f14d3', '系统配置', '/mgt/systemConfig/toSystemConfig.ihtml', null, 'root-11-1', '系统配置', '11', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('098c3ef329414c918056f4a9c174d1b1', '车辆信息管理', 'null', null, 'root-5', '车辆信息管理', '3', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('0b677f296f6949d3a8d179dd8bda6c6e', '排档维护', '/mgt/gear/toGear.ihtml', null, 'root-5-5', '排档维护', '55', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('0b75d3a6bbbb44fea5a6b537deb001fb', '广告管理', '/mgt/ads/toAds.ihtml', '0', 'root-4', '广告管理', '8', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('10b9cf12df5f481d8de91b5c89b1d887', '权限管理', 'null', null, 'root-16', '权限管理', '10', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('2f76498bfd1948e2921498ed43fe1ea0', '价格段维护', '/mgt/priceScep/toPriceScep.ihtml', null, 'root-5-7', '价格段维护', '56', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('34097c5d92d7419790c43adf4d8dfde8', '车辆类型维护', '/mgt/carType/toCarType.ihtml', null, 'root-5-3', '车辆类型维护', '53', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('3991b30c1bef40afaedd8cbe885d257a', 'BC会员管理', 'null', '1', 'root-3', 'BC会员管理', '2', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('41661c6274444e198f943843f5c0e686', '权限资源管理', '/mgt/authorityresources/toResourcesManage.ihtml', null, 'root-16-2', '权限资源管理', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('4a45a22523314b9bb42e7efddb1df79f', '会员优惠劵', '/mgt/memberCoupons/toMemberCoupons.ihtml', null, 'root-6-2', '会员优惠劵', '62', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('5d2af7182957428096f60f57bf33acac', '订单管理', '/mgt/order/toOrder.ihtml', '0', 'root-2', '订单管理', '4', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('5eb90c5b5c404fa89287f5ae2053571e', '系统日志', '/mgt/systemLog/toSystemLog.ihtml', null, 'root-11-3', '系统日志', '11', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('620bcb15893b4eadba5abaa95e9779c9', '排量维护', '/mgt/displacement/toDisplacement.ihtml', null, 'root-5-6', '排量维护', '56', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('66132a5079974028bf713b4e64017cc3', '优惠劵方案管理', '/mgt/couponsPlan/toCouponsPlan.ihtml', null, 'root-6-1', '优惠劵方案管理', '61', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('73d1e82f2d6c40618873deb98a9ee165', '促销活动', 'null', null, 'root-17', '权限资源目录', '6', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('7ebb26d253294d46b38e5dc755c3c194', '反馈维护', '/mgt/feedBack/toFeedBack.ihtml', null, 'root-7', '反馈维护', '6', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('860b68ad2a7146729bf2e04c7dcd1d58', '优惠劵管理', 'null', null, 'root-6', '优惠劵管理', '5', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('9135fa30700542e8bf77659078f90da9', '品牌维护', '/mgt/brand/toBrand.ihtml', null, 'root-5-2', '品牌维护', '52', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('94db37da66c44be9bb5f4d36a6e91125', '系统管理（首页）', '/mgt/mainmanage/mainFirst.ihtml', '0', 'root-1', '系统管理（首页）', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('997856a07dff49c994cc6ad598969cc1', '会员管理', '/mgt/member/toMember.ihtml', '0', 'root-3-1', '会员管理', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('99d02ed9743e44ac8d309d193afc2aed', 'æ–°å¢žæŽ’æŒ¡ç»´æŠ¤', '/mgt/gear/addGear.ihtml', null, 'root-5-5-1', 'æƒé™èµ„æº', '551', '1', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('9d95dbb03c9940a4990ef2964253d47d', '车型维护', '/mgt/carSerial/toCarSerial.ihtml', null, 'root-5-4', '车型维护', '54', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('b950bcd483a841bc956a80d095d4b7eb', '促销活动列表', '/mgt/active/toActive.ihtml', null, 'root-17-1', '权限资源目录', '6', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('c1e99241794a460f9195dbf7f8bb231f', '系统管理', 'null', null, 'root-11', '系统管理', '9', '0', '0', '1');
INSERT INTO `t_authority_resources` VALUES ('cc33847e51f54943b4816e0b0ef09f72', '租赁商车辆管理', '/mgt/companyCar/toCompanyCar.ihtml', null, 'root-5-1', '租赁商车辆管理', '51', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('cf4fd5b6d12a494a92128fa8a0f73b50', '角色管理', '/mgt/systemRole/toSystemRole.ihtml', null, 'root-16-3', '角色管理', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('d02ec792d3024d31a0ecf95c84795d99', '保险规则配置', '/mgt/systemConfig/toUpdateInsuranceRuleConfig.ihtml', null, 'root-11-2', '保险规则配置', '11', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('d8ada3b70f674443a989ce7f533d7760', '租赁商管理', '/mgt/company/toCompany.ihtml', '0', 'root-3-2', '租赁商管理', '2', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('eb19a7984d53463dace1502f50963dad', '系统用户管理', '/mgt/systemUser/toSystemUser.ihtml', null, 'root-16-1', '系统用户管理', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('eec0fc39278f4776abaabd974b18c40d', '会员钱包', '/mgt/myVoucher/toMyVoucher.ihtml', null, 'root-18-1', '权限资源目录', '1', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('f4112640320f45f59022a8f0ada60cd9', '车辆收发点管理', '/mgt/platformAddress/toPlatformAddress.ihtml', null, 'root-8', '车辆收发点管理', '7', '0', '1', '1');
INSERT INTO `t_authority_resources` VALUES ('fd940e3900d642589c4a6704c7e9816a', '会员账户管理', 'null', null, 'root-18', '权限资源目录', '7', '0', '0', '1');

-- ----------------------------
-- Table structure for t_authority_role
-- ----------------------------
DROP TABLE IF EXISTS `t_authority_role`;
CREATE TABLE `t_authority_role` (
  `ID` varchar(32) NOT NULL COMMENT 'id',
  `ROLE_NAME` varchar(150) default NULL COMMENT 'role_name',
  `T_NO` varchar(40) default NULL COMMENT 'no',
  `ROLE_CREATEDATE` timestamp NOT NULL default CURRENT_TIMESTAMP COMMENT 'role_createdate',
  `REMARK` varchar(200) default NULL COMMENT 'remark',
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='è§’è‰²';

-- ----------------------------
-- Records of t_authority_role
-- ----------------------------
INSERT INTO `t_authority_role` VALUES ('618a5320ff574908872314a144c44fb9', '超级管理员', null, '2015-01-28 00:35:18', '所有权限');

-- ----------------------------
-- Table structure for t_authority_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `t_authority_role_menu`;
CREATE TABLE `t_authority_role_menu` (
  `ID` varchar(32) NOT NULL COMMENT 'id',
  `MENU_ID` varchar(32) default NULL COMMENT 'menu_id',
  `ROLE_ID` varchar(32) default NULL COMMENT 'role_id',
  PRIMARY KEY  (`ID`),
  KEY `FK_REFERENCE_12` (`MENU_ID`),
  KEY `FK_REFERENCE_13` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='è§’è‰²èµ„æºæ˜ å°„';

-- ----------------------------
-- Records of t_authority_role_menu
-- ----------------------------
INSERT INTO `t_authority_role_menu` VALUES ('015d21297a4d40d48c36bdb60f93cecd', '34097c5d92d7419790c43adf4d8dfde8', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('0d985081226c4bb8a2c833d0c3be377e', '0b75d3a6bbbb44fea5a6b537deb001fb', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('0efd2caf736a473fbf983b9b1c0d0340', 'd02ec792d3024d31a0ecf95c84795d99', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('11ad22d6e3a8424e8d30d8fcde1ad66c', '9135fa30700542e8bf77659078f90da9', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('12f7c2def48a45f5a40e07506e20e207', '3991b30c1bef40afaedd8cbe885d257a', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('178b92cb49524067aff44cc43fff2bd3', '0', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('1ab9ae0881d9446fafbc29befeee560f', 'c1e99241794a460f9195dbf7f8bb231f', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('38ea67381b65471fa1e29e9e26382629', '5d2af7182957428096f60f57bf33acac', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('48f32b5ffb934eba9a540f14e8a3019b', 'f4112640320f45f59022a8f0ada60cd9', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('49eda6af4df943afbf290d31b127b94b', '860b68ad2a7146729bf2e04c7dcd1d58', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('50c20a21cc48425cb2142816b2cd211c', 'eec0fc39278f4776abaabd974b18c40d', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('558c11944f7847d183e50c3297dc77ce', 'cf4fd5b6d12a494a92128fa8a0f73b50', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('5be17c7cffa54c758622b035a37d763f', 'd8ada3b70f674443a989ce7f533d7760', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('61e0a92fe0c942e989ed7effa7698753', '94db37da66c44be9bb5f4d36a6e91125', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('6bed5ea11a8547788242965772f77c7a', 'eb19a7984d53463dace1502f50963dad', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('76c56d6049ed4f04bcd0593b0307130e', '4a45a22523314b9bb42e7efddb1df79f', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('8b88ea0ab87c4292ad38ccc603bd2c2f', '098c3ef329414c918056f4a9c174d1b1', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('8b9227fa293b48658cc680423acaa4c4', 'cc33847e51f54943b4816e0b0ef09f72', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('9543c46351254cb38e7721fb44253f4b', '10b9cf12df5f481d8de91b5c89b1d887', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('9912c10d6e114de4b4de5045870bfc4b', '997856a07dff49c994cc6ad598969cc1', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('9d10b92fe24c4240a38f9a85acb6c56d', 'fd940e3900d642589c4a6704c7e9816a', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('a88198cffab74dad897fb5ec33f1d866', '620bcb15893b4eadba5abaa95e9779c9', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('a9557ab954974335b114be78bdcb74e2', '5eb90c5b5c404fa89287f5ae2053571e', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('ad870b13f1854d1cb5e788b3c4b88a30', '0b677f296f6949d3a8d179dd8bda6c6e', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('bb8d610519704398b5129610acaf2475', '2f76498bfd1948e2921498ed43fe1ea0', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('bc8db6050b9c4f5f875d5a867df443b0', '73d1e82f2d6c40618873deb98a9ee165', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('d17ff0315db74fa4b46926f1f1a43c66', '41661c6274444e198f943843f5c0e686', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('dafee29ea2144b6f84b7cba30908cfc9', '027f6c0a06154810bbed8de90c9f14d3', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('dbd56643ced844b1a1d5383eb23248db', '66132a5079974028bf713b4e64017cc3', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('e7691c13f753446dade1779a85a96998', 'b950bcd483a841bc956a80d095d4b7eb', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('f4f0b0b34c774140bde5b26720caa7a3', '7ebb26d253294d46b38e5dc755c3c194', '618a5320ff574908872314a144c44fb9');
INSERT INTO `t_authority_role_menu` VALUES ('fc0ed2b44c9f47598095d98c14bc7c70', '9d95dbb03c9940a4990ef2964253d47d', '618a5320ff574908872314a144c44fb9');

-- ----------------------------
-- Table structure for t_authority_user_role
-- ----------------------------
DROP TABLE IF EXISTS `t_authority_user_role`;
CREATE TABLE `t_authority_user_role` (
  `ID` varchar(32) NOT NULL COMMENT 'id',
  `USER_ID` varchar(32) default NULL COMMENT 'user_id',
  `ROLE_ID` varchar(32) default NULL COMMENT 'role_id',
  PRIMARY KEY  (`ID`),
  KEY `FK_REFERENCE_30` (`USER_ID`),
  KEY `FK_REFERENCE_31` (`ROLE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ç”¨æˆ·è§’è‰²æ˜ å°„';

-- ----------------------------
-- Records of t_authority_user_role
-- ----------------------------
INSERT INTO `t_authority_user_role` VALUES ('b671af4c06fd4dd699697286a14a73b6', '1', '618a5320ff574908872314a144c44fb9');

-- ----------------------------
-- Table structure for t_brand
-- ----------------------------
DROP TABLE IF EXISTS `t_brand`;
CREATE TABLE `t_brand` (
  `id` int(11) NOT NULL auto_increment,
  `brand_code` varchar(20) default NULL COMMENT '品牌编码',
  `brand_name` varchar(50) default NULL COMMENT '品牌名称',
  `brand_pic` varchar(200) default NULL COMMENT '品牌图片',
  `brand_url` varchar(200) default NULL COMMENT '品牌网址',
  `create_date` datetime default NULL,
  `brand_py` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `brand_code` (`brand_code`),
  UNIQUE KEY `brand_code_2` (`brand_code`),
  UNIQUE KEY `brand_code_3` (`brand_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='品牌维护';

-- ----------------------------
-- Records of t_brand
-- ----------------------------
INSERT INTO `t_brand` VALUES ('1', 'audi', '奥迪', 'upload/brand/0.44246474353976917lake.jpg', 'www.audi.com', '2015-01-21 21:47:19', 'audi');
INSERT INTO `t_brand` VALUES ('2', 'benz', '奔驰', 'upload/0.24794636611787035lake.jpg', '', '2015-01-13 22:58:07', 'benz');
INSERT INTO `t_brand` VALUES ('3', 'honda', '本田', null, null, '2015-01-13 22:58:07', 'BT');
INSERT INTO `t_brand` VALUES ('4', 'buick', '别克', null, null, '2015-01-13 22:58:07', 'BK');
INSERT INTO `t_brand` VALUES ('5', 'ford', '福特', null, null, '2015-01-14 10:25:17', 'FD');
INSERT INTO `t_brand` VALUES ('6', 'volkswagen', '大众', null, null, '2015-01-13 22:58:07', 'DZ');
INSERT INTO `t_brand` VALUES ('7', 'toyota', '丰田', null, null, '2015-01-13 22:58:07', 'FT');
INSERT INTO `t_brand` VALUES ('8', 'mazda', '马自达', null, null, '2015-01-13 22:58:07', 'MZD');
INSERT INTO `t_brand` VALUES ('9', 'roewe', '荣威', null, null, '2015-01-13 22:58:07', 'RW');
INSERT INTO `t_brand` VALUES ('10', 'mitsubishi', '三菱', null, null, '2015-01-13 22:58:07', 'SL');
INSERT INTO `t_brand` VALUES ('11', 'hyundai', '现代', null, null, '2015-01-13 22:58:07', 'XD');
INSERT INTO `t_brand` VALUES ('12', 'nissan', '日产', null, null, '2015-01-13 22:58:07', 'RC');
INSERT INTO `t_brand` VALUES ('13', 'volvo', '沃尔沃', null, '', '2015-01-23 14:53:06', 'WEW');
INSERT INTO `t_brand` VALUES ('14', 'jac', '江淮', null, '', '2015-01-15 15:39:48', 'JH');
INSERT INTO `t_brand` VALUES ('15', 'dongfeng', '东风', null, '', '2015-01-19 10:46:58', 'DF');
INSERT INTO `t_brand` VALUES ('16', 'peugeot', '标致', null, '', '2015-01-19 20:09:30', 'BZ');
INSERT INTO `t_brand` VALUES ('17', 'fengtian-saina', '丰田赛纳', null, '', '2015-02-02 22:20:30', 'FTSN');
INSERT INTO `t_brand` VALUES ('18', 'lexus', '雷克萨斯', null, '', '2015-01-23 14:54:41', 'LKSS');
INSERT INTO `t_brand` VALUES ('19', 'futian', '福田', null, '', '2015-01-19 19:22:33', 'FT');
INSERT INTO `t_brand` VALUES ('20', 'citroen', '雪铁龙', null, '', '2015-01-23 14:51:44', 'XTL');
INSERT INTO `t_brand` VALUES ('21', 'subaru', '斯巴鲁', null, '', '2015-01-23 14:47:04', 'SBL');
INSERT INTO `t_brand` VALUES ('22', 'venucia', '启辰', null, '', '2015-01-23 15:00:41', 'QC');
INSERT INTO `t_brand` VALUES ('23', 'chevrolet', '雪弗兰', null, 'chevrolet', '2015-01-19 10:46:45', 'XFL');
INSERT INTO `t_brand` VALUES ('24', 'changan', '长安', null, '', '2015-01-19 10:44:57', 'ZA');
INSERT INTO `t_brand` VALUES ('25', 'beiqi', '北汽', null, '', '2015-01-21 21:46:43', 'BQ');
INSERT INTO `t_brand` VALUES ('29', 'kia', '起亚', null, '', '2015-01-19 10:44:40', 'QY');
INSERT INTO `t_brand` VALUES ('30', 'chery', '奇瑞', null, 'www.chery.com', '2015-01-23 14:58:45', 'chery');
INSERT INTO `t_brand` VALUES ('31', 'haima', '海马', null, 'www.haima.com', '2015-01-13 22:58:07', 'haima');
INSERT INTO `t_brand` VALUES ('39', 'rain', '大雨', 'upload/brand/0.14529506784616675', 'xixi', null, null);

-- ----------------------------
-- Table structure for t_car_serial
-- ----------------------------
DROP TABLE IF EXISTS `t_car_serial`;
CREATE TABLE `t_car_serial` (
  `id` int(11) NOT NULL auto_increment,
  `brand_code` varchar(20) default NULL COMMENT '品牌编码',
  `SERIAL_CODE` varchar(50) default NULL COMMENT '车系code',
  `SERIAL_NAME` varchar(200) default NULL COMMENT '车系名称',
  `create_date` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `SERIAL_CODE` (`SERIAL_CODE`),
  UNIQUE KEY `SERIAL_CODE_2` (`SERIAL_CODE`),
  UNIQUE KEY `SERIAL_CODE_3` (`SERIAL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车系维护';

-- ----------------------------
-- Records of t_car_serial
-- ----------------------------
INSERT INTO `t_car_serial` VALUES ('1', 'audi', 'AUDI_A6L', 'A6L', null);
INSERT INTO `t_car_serial` VALUES ('2', 'benz', 'benzS', 'S系', null);
INSERT INTO `t_car_serial` VALUES ('3', 'dongfeng', 'fengxing', '风行', '2015-01-19 20:07:08');
INSERT INTO `t_car_serial` VALUES ('4', 'kia', 'SUOLATU', '索拉图', '2015-01-19 21:23:18');
INSERT INTO `t_car_serial` VALUES ('5', 'haima', 'haimam5', 'M5', '2015-01-21 21:55:15');
INSERT INTO `t_car_serial` VALUES ('6', 'nissan', 'richan', '轩逸', '2015-02-03 21:28:57');
INSERT INTO `t_car_serial` VALUES ('7', 'ford', 'FOCUS', '福克斯', '2015-01-19 21:10:57');
INSERT INTO `t_car_serial` VALUES ('8', 'toyota', 'AIERFA', '埃尔法', '2015-01-19 21:37:44');
INSERT INTO `t_car_serial` VALUES ('9', 'audi', 'AUDI_A7', 'A7', '2015-01-19 19:36:53');
INSERT INTO `t_car_serial` VALUES ('10', 'volkswagen', 'PASSAT', '帕萨特', '2015-01-19 21:41:00');
INSERT INTO `t_car_serial` VALUES ('11', 'toyota', 'fengtianweichi', '威驰', '2015-02-03 12:57:15');
INSERT INTO `t_car_serial` VALUES ('12', 'beiqi', 'beiqE', 'E级', '2015-01-21 21:59:28');
INSERT INTO `t_car_serial` VALUES ('13', 'honda', 'CRV', 'CRV', '2015-01-19 21:13:58');
INSERT INTO `t_car_serial` VALUES ('14', 'chevrolet', 'xuefulansaiou', '赛欧', '2015-01-19 19:55:34');
INSERT INTO `t_car_serial` VALUES ('15', 'toyota', 'ruizhi', '锐志', '2015-01-19 21:35:14');
INSERT INTO `t_car_serial` VALUES ('16', 'buick', 'angkelei', '昂科雷', '2015-01-19 19:48:52');
INSERT INTO `t_car_serial` VALUES ('17', 'audi', 'AUDI_Q3', 'Q3', '2015-01-17 15:46:03');
INSERT INTO `t_car_serial` VALUES ('18', 'benz', 'benzC', 'C系', '2015-01-19 21:02:55');
INSERT INTO `t_car_serial` VALUES ('19', 'mitsubishi', 'GELAN', '戈蓝', '2015-01-19 21:25:33');
INSERT INTO `t_car_serial` VALUES ('20', 'toyota', 'fengtianxuanyi', '轩逸', '2015-02-03 12:58:11');
INSERT INTO `t_car_serial` VALUES ('21', 'roewe', '350', '350', '2015-01-19 21:33:21');
INSERT INTO `t_car_serial` VALUES ('22', 'benz', 'benchismart', 'smart', '2015-01-19 11:04:41');
INSERT INTO `t_car_serial` VALUES ('23', 'dongfeng', 'dongfengruiqi', '锐琪', '2015-01-19 11:32:14');

-- ----------------------------
-- Table structure for t_car_type
-- ----------------------------
DROP TABLE IF EXISTS `t_car_type`;
CREATE TABLE `t_car_type` (
  `id` varchar(32) NOT NULL,
  `car_type_code` varchar(10) default NULL COMMENT '车型编码',
  `car_type_name` varchar(50) default NULL COMMENT '车型名称',
  `create_date` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `car_type_code` (`car_type_code`),
  UNIQUE KEY `car_type_code_2` (`car_type_code`),
  UNIQUE KEY `car_type_code_3` (`car_type_code`),
  UNIQUE KEY `car_type_code_4` (`car_type_code`),
  UNIQUE KEY `car_type_code_5` (`car_type_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='车型维护';

-- ----------------------------
-- Records of t_car_type
-- ----------------------------
INSERT INTO `t_car_type` VALUES ('10001', 'SATWO', '轿车（两厢）', '2015-01-13 22:57:52');
INSERT INTO `t_car_type` VALUES ('10002', 'SATHREE', '轿车（三厢）', '2015-01-13 22:57:52');
INSERT INTO `t_car_type` VALUES ('77ff7caf4a5946a4af59d96a3513b488', 'zhongba', '中巴', '2015-02-08 18:22:47');
INSERT INTO `t_car_type` VALUES ('973ad7244b164e7a9cbbd8e8a2c9dba3', 'SC', '跑车', '2015-01-15 15:42:13');
INSERT INTO `t_car_type` VALUES ('c7478b0e727748b48d660a97c7442202', 'benchi', '敞篷车', '2015-02-03 21:20:22');
INSERT INTO `t_car_type` VALUES ('de760061981b4725b837c90af98adca5', 'PT', '皮卡', '2015-01-15 15:42:05');
INSERT INTO `t_car_type` VALUES ('e0a5e89f560c4fb78e127bc9641efa42', 'SUV', '越野', '2015-01-15 15:43:32');
INSERT INTO `t_car_type` VALUES ('e8b21bab789146698a97ade25655e1cb', 'Minicar', '微型车', '2015-01-19 19:23:59');
INSERT INTO `t_car_type` VALUES ('ea483c7de33b43d8a4570b6ad3cf0f27', 'CV', '商务车', '2015-01-15 15:43:25');

-- ----------------------------
-- Table structure for t_company
-- ----------------------------
DROP TABLE IF EXISTS `t_company`;
CREATE TABLE `t_company` (
  `id` int(32) NOT NULL,
  `company_name` varchar(200) default NULL COMMENT '公司名称',
  `lease_name` varchar(32) default NULL COMMENT '联系人',
  `telephone` varchar(15) default NULL COMMENT '联系电话',
  `mobile_phone` varchar(15) default NULL COMMENT '联系手机',
  `address` varchar(200) default NULL COMMENT '商家地址',
  `mail` varchar(32) default NULL COMMENT '邮箱地址',
  `open_bank` varchar(50) default NULL COMMENT '商家开户行',
  `bank_account` varchar(32) default NULL COMMENT '商家银行账号',
  `remark` varchar(500) default NULL COMMENT '商家简介',
  `audit_state` int(11) default NULL COMMENT '审核状态',
  `enabled` int(11) default NULL COMMENT '启用,禁用状态',
  `del_state` int(11) default NULL COMMENT '删除状态',
  `create_date` datetime default NULL,
  `car_desc` varchar(200) default NULL COMMENT '车辆描述',
  `AREA` varchar(100) default NULL,
  `fault_name` varchar(32) default NULL COMMENT 'æ•…éšœè”ç³»äººåç§°',
  `fault_phone` varchar(32) default NULL COMMENT 'æ•…éšœè”ç³»äººç”µè¯',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租赁商标';

-- ----------------------------
-- Records of t_company
-- ----------------------------
INSERT INTO `t_company` VALUES ('1', '海南万鸿', '张海宝', '13698930036', '13698930036', '海口', '', '', null, '', null, '1', null, '2015-01-20 21:54:08', null, null, '张海浪', '18976086962');
INSERT INTO `t_company` VALUES ('2', '文涛租车', '文涛', '15308983331', '15308983331', '海口市', '', '', null, '', null, '1', null, '2015-02-11 17:52:34', null, null, '文涛', '15308983331');
INSERT INTO `t_company` VALUES ('3', '测试商家', '测试商家', '13723741996', '13723741996', '海南', '', '', null, '', null, '1', null, '2015-02-04 23:10:35', null, null, 'xy', '13717026100');
INSERT INTO `t_company` VALUES ('4', '五合租车', '李天魁', '13807560456', '13807560456', '海口', '799129363@qq.com', '', null, '', null, '1', null, '2015-01-20 22:53:31', null, null, '李天魁', '13807560456');
INSERT INTO `t_company` VALUES ('5', '椰辉租车', '郭振飞', '18889682008', '18889682008', '三亚', '330858628@qq.com', '', null, '', null, '1', null, '2015-01-20 22:42:50', null, null, '郭振飞', '18889682008');
INSERT INTO `t_company` VALUES ('6', '十八度阳光', '徐洁', '13158900007', '13158900007', '', 'sanya18du03@sina', '', null, '', null, '1', null, '2015-01-30 00:09:46', null, null, '徐洁', '13158900007');
INSERT INTO `t_company` VALUES ('7', '海航思福租车', '蔡小红', '0898-66531006', '18689846001', '海南', '', '', null, '', null, '1', null, '2015-01-20 21:59:00', null, null, '符传宇', '17789799700');
INSERT INTO `t_company` VALUES ('8', '海南小二', '刘倩', '17789885998', '17789885998', '', '', '', null, '', null, '0', null, '2015-03-01 12:08:27', null, null, '刘倩', '17789885998');
INSERT INTO `t_company` VALUES ('9', '易捷租车', '张总', '18308943332', '18889876767', '三亚', '114279128@qq.com', '', null, '', null, '1', null, '2015-01-20 22:07:07', null, null, '李莹', '18308943332');
INSERT INTO `t_company` VALUES ('10', '顺通租车', '吴非', '13278980288', '13278980288', '', '', '', null, '', null, '1', null, '2015-02-12 18:18:58', null, null, '13278980288', '13278980288');
INSERT INTO `t_company` VALUES ('11', '万里祥顺', '符传文', '18289587943', '18289587943', '海口', '', '', null, '', null, '1', null, '2015-02-22 16:45:29', null, null, '符传文', '18289587943');
INSERT INTO `t_company` VALUES ('12', '思福行政车队', '肖文杰', '13707528168', '13707528168', '海口', '', '', null, '', null, '1', null, '2015-02-08 17:39:04', null, null, '肖文杰', '13707528168');
INSERT INTO `t_company` VALUES ('13', '金太阳租车', '王小伟', '谭经理13707586546', '13005006610', '海口市海甸岛五中路蓝康城一楼4号门面', '', '', null, '', null, '1', null, '2015-01-20 21:31:49', null, null, null, null);
INSERT INTO `t_company` VALUES ('14', '神马租车', '高辉', '18976610008', '18976610008', '解放四路1066号金泉海景公寓', '408222211@qq.com', '', null, '', null, '1', null, '2015-01-30 00:11:31', null, null, '神马租车', '13379811717');
INSERT INTO `t_company` VALUES ('15', '三亚亚欣', '陈蕊', '13346008333', '13346008333', '三亚湾碧海蓝天', '745200171@qq.com', '', null, '', null, '1', null, '2015-02-03 12:54:36', null, null, '陈蕊', '13346008333');
INSERT INTO `t_company` VALUES ('16', '金色坦途', '孙柱国', '18889188507', '18889188507', '三亚市', '47475091@qq.com', '', null, '', null, '1', null, '2015-01-31 15:18:33', null, null, '孙柱国', '18889188507');
INSERT INTO `t_company` VALUES ('17', '浪琴湾', '卢章全', '15308966888', '15308966888', '海口市 美兰区 国兴大道 大英山 西山路 22号 八一小区 10栋1号铺面', '261356348@qq', '', null, '', null, '1', null, '2015-01-20 22:48:34', null, null, '卢章全', '15308966888');
INSERT INTO `t_company` VALUES ('18', '假日岛租车', '别少男', '13519890342', '13519890342', '海口国贸', '', '', null, '', null, '1', null, '2015-02-03 21:11:02', null, null, '昌湾', '13876377573');

-- ----------------------------
-- Table structure for t_company_car
-- ----------------------------
DROP TABLE IF EXISTS `t_company_car`;
CREATE TABLE `t_company_car` (
  `id` int(11) NOT NULL auto_increment,
  `lease_id` int(32) default NULL COMMENT '租赁商id',
  `car_no` varchar(32) default NULL COMMENT '车辆编号',
  `car_name` varchar(100) default NULL COMMENT '车辆名称',
  `car_type` varchar(20) default NULL COMMENT '车辆类型',
  `car_brand` varchar(32) default NULL COMMENT '车辆品牌',
  `car_serial` varchar(20) default NULL COMMENT '车系编号',
  `normal_price` double(20,2) default NULL COMMENT '车辆价格普通价',
  `holiday_price` double(20,2) default NULL COMMENT '车辆假日价',
  `special_price` double(20,2) default NULL COMMENT '车辆特殊价',
  `gear` varchar(32) default NULL COMMENT '排挡',
  `displacement` varchar(32) default NULL COMMENT '排量',
  `seating` int(11) default NULL COMMENT '座位数',
  `car_quantity` int(11) default NULL COMMENT '车辆数量',
  `plate_double` varchar(10) default NULL COMMENT '车辆车牌(扩展用,暂不用)',
  `car_pic` varchar(200) default NULL COMMENT '车辆图片(扩展用,暂不用)',
  `audit_state` int(11) default NULL COMMENT '车辆审核状态',
  `updown_state` int(11) default NULL COMMENT '车辆上下架状态',
  `car_desc` varchar(200) default NULL COMMENT '车辆描述',
  `create_date` datetime default NULL,
  `has_navigat` int(11) default NULL COMMENT '有无导航0无,1有',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租赁商车辆信息';

-- ----------------------------
-- Records of t_company_car
-- ----------------------------
INSERT INTO `t_company_car` VALUES ('1', '2', '476624372a3d64645', '现代伊兰特', 'SATHREE', 'hyundai', 'ELANTRA', '220.00', '280.00', '650.00', 'ZD', '1.6T', '5', '3', '', 'upload/car/0.188994532298148lake.jpg', '0', '0', '黑色', null, '0');
INSERT INTO `t_company_car` VALUES ('2', '3', 'eaeac892891910d02', '丰田凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '450.00', '1300.00', 'ZD', '2.0 ', '5', '5', null, 'toyota_kaimeirui.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('3', '2', '09f9aea2850fdd522', '大众朗逸', 'SATHREE', 'volkswagen', 'volkswagen_LY', '300.00', '350.00', '850.00', 'ZD', '1.8 ', '5', '1', null, 'volkswagen_langyi1.jpg', null, '0', '黑色', null, null);
INSERT INTO `t_company_car` VALUES ('4', '1', '8ea8b30d41c4a51de2', '丰田威驰', 'SATHREE', 'toyota', 'weichi', '200.00', '250.00', '600.00', 'ZD', '1.4 ', '5', '10', null, 'toyota_weichi.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('5', '3', '4c32bafea9665a7bf158', '雪弗兰 科鲁兹', 'SATHREE', 'chevrolet', 'keluzi', '220.00', '280.00', '500.00', 'ZD', '1.6 ', '5', '2', null, '', null, '1', '导航，真皮座椅，倒车影像，车况非常好', null, null);
INSERT INTO `t_company_car` VALUES ('6', '6', '06aad998764f8fbaef', '丰田RAV4', 'SUV', 'toyota', 'RAV4', '480.00', '480.00', '1200.00', 'ZD', '2.0 ', '5', '2', null, 'toyota_RAV4.jpg', null, '0', '黑色 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('7', '5', '0ac1055476624372a3d', '东风 锐琪', 'PT', 'dongfeng', 'dongfengruiqi', '300.00', '300.00', '300.00', 'SD', '2.2', '5', '30', null, 'dongfeng_yj.jpg', null, null, '全新 蓝色 真皮 赠送全险', null, null);
INSERT INTO `t_company_car` VALUES ('8', '8', '0ac1055476624372a3d1', '奔驰 S系', 'SATHREE', 'benz', 'benzS', '2000.00', '2000.00', '3800.00', 'ZD', '3.5 ', '5', '3', null, 'benz-s.jpg', null, null, '', null, null);
INSERT INTO `t_company_car` VALUES ('9', '7', 'ac5ce143c911a4b3', '本田', 'SATHREE', 'honda', 'CIVIC', '230.00', '280.00', '500.00', 'ZD', '1.8 ', '5', '7', null, 'honda_shiyu.jpg', null, '0', '黑色 、灰色、导航 、真皮 、天窗、 巡航 、多功能方向盘 、电动座椅、倒车可视。', null, null);
INSERT INTO `t_company_car` VALUES ('10', '7', '11a73e7b3c6d6a5cdc52', '本田 雅阁2.0', 'SATHREE', 'honda', 'bentianyage2.0', '300.00', '300.00', '300.00', 'ZD', '2.0 ', '5', '10', null, 'bentian-yage.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('11', '3', '13ba59712b9a355e6c8', '大众 宝来', 'SATHREE', 'volkswagen', 'BORA', '260.00', '480.00', '980.00', 'ZD', '1.6 ', '5', '1', null, 'volkswagen_baolai.jpg', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('12', '2', '14e942b443b411774b75', '现代名图', 'SATHREE', 'hyundai', 'xiandaimingtu', '300.00', '300.00', '600.00', 'ZD', '1.8 ', '5', '2', null, 'tusheng.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('13', '3', 'b8e057401a2dbdbc5', '丰田卡罗拉', 'SATHREE', 'toyota', 'fengtiankaluola', '400.00', '450.00', '850.00', 'ZD', '1.8 ', '5', '1', null, 'toyota_kaluola.jpg', null, '1', '银色 黑色 咖啡色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('14', '5', '181fa35ae954d4f1f', '奥迪 A1特价车', 'SATWO', 'audi', 'audi_A1_special', '0.00', '288.00', '720.00', 'ZD', '1.4T', '5', '10', null, 'audi_A1_fad1.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('15', '7', '18794a844b1fa5e7de2', '丰田 凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '500.00', '500.00', '1000.00', 'ZD', '2.0 ', '5', '1', null, '', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('16', '8', '182bcbfb0b61cabfbbe', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '400.00', '400.00', '1700.00', 'ZD', '2.4 ', '7', '0', null, 'buickluzun.jpg', null, '1', '自动挡，皮座椅，13年末车，非常新', null, null);
INSERT INTO `t_company_car` VALUES ('17', '9', '1daa88ad7f59ea9fe7', '江淮 瑞风', 'CV', 'jac', 'jianghuairuifeng', '450.00', '540.00', '1298.00', 'SD', '2.0 ', '12', '1', null, '', null, '1', '手动档，银色，布艺座椅', null, null);
INSERT INTO `t_company_car` VALUES ('18', '10', '1bab4f111e4f43d76f3', '日产 骐达', 'SATWO', 'nissan', 'qidarich', '260.00', '300.00', '550.00', 'ZD', '1.6 ', '5', '5', null, '', null, '1', '14年新车，导航，倒车影像', null, null);
INSERT INTO `t_company_car` VALUES ('19', '17', '1d1bff13dc0719604d1', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '350.00', '450.00', '1300.00', 'SD', '2.4 ', '9', '4', null, 'jac_rf1.jpg', null, '0', '银色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('20', '14', '8c830b653bfbf51795', '大众 捷达', 'SATHREE', 'volkswagen', 'JIEDA', '258.00', '450.00', '500.00', 'ZD', '1.6 ', '5', '3', null, 'volkswagen_jieda1.jpg', null, '1', '黑色', null, null);
INSERT INTO `t_company_car` VALUES ('21', '12', '1d9564775aa9f8da6c', '别克路尊', 'CV', 'buick', 'biekeshangwu', '450.00', '550.00', '2000.00', 'ZD', '2.4 ', '7', '5', null, 'buickluzun.jpg', null, '0', '银色 真皮座椅 多功能方向盘 GPS导航 定速巡航 天窗', null, null);
INSERT INTO `t_company_car` VALUES ('22', '13', '04ae4e176740cb3edb', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '200.00', '230.00', '500.00', 'ZD', '1.6 ', '5', '7', null, 'toyota_huaguan.jpg', null, '0', '黑色 导航 真皮 天窗', null, null);
INSERT INTO `t_company_car` VALUES ('23', '16', '5a8a890dce98ff18bda', '大众 桑塔纳', 'SATHREE', 'volkswagen', 'SANTANA', '268.00', '268.00', '600.00', 'ZD', '1.6 ', '5', '1', null, 'volkswagen_sangtana.jpg', null, '0', '13年12月份车。自动挡，导航，倒车影像。', null, null);
INSERT INTO `t_company_car` VALUES ('24', '13', '0ac10624372a3d2', '马自达 8', 'SATHREE', 'mazda', 'mazda8', '500.00', '500.00', '1500.00', 'ZD', '2.5 ', '7', '1', null, 'mazda3.jpg', null, null, '真皮座椅 多功能方向盘 多媒体导航 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('25', '2', '25589b9ff00390b31e4', '奥迪A6L', 'SATHREE', 'audi', 'AUDI_A6L', '1200.00', '1200.00', '2800.00', 'ZD', '2.0 ', '5', '2', null, 'audi_A6L.jpg', null, '0', '黑色 真皮座椅 导航 雷达倒车 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('26', '5', '89a99507275e914695', '奥迪A1', 'SATWO', 'audi', 'AUDI_A1', '288.00', '288.00', '720.00', 'ZD', '1.4T', '5', '10', null, 'audi_A1_fad1.jpg', null, '1', '白色 红色 真皮座椅 方向盘 GPS 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('27', '16', '9c43b0ed4bc427aa', '丰田锐志', 'SATHREE', 'toyota', 'ruizhi', '400.00', '400.00', '700.00', 'ZD', '2.5 ', '5', '1', null, 'toyota_ruizhi.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('28', '17', '27d7aa24abc94d3feaf5', '大众 甲壳虫', 'SC', 'volkswagen', 'dazhongjiakechong', '588.00', '588.00', '1000.00', 'ZD', '2.0 ', '4', '2', null, '', null, '1', '自动挡，带导航，倒车雷达，皮座椅。', null, null);
INSERT INTO `t_company_car` VALUES ('29', '2', '28b8b2a469da32e56c', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '450.00', '450.00', '1200.00', 'ZD', '2.4 ', '8', '4', null, 'jac_rf1.jpg', null, '1', '银色', null, null);
INSERT INTO `t_company_car` VALUES ('30', '6', '29c06140a3db3afb3', '长安 CS75', 'SUV', 'changan', 'changancs75', '350.00', '400.00', '600.00', 'ZD', '1.8T', '5', '2', null, '', null, '1', '真皮座椅 多功能方向盘 多媒体导航 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('31', '7', '23987e3ef7ef6d28a2', '本田 雅阁-外', 'SATHREE', 'honda', 'bentian-yage-wai', '400.00', '400.00', '800.00', 'ZD', '1.6 ', '5', '2', null, '', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('32', '8', '2e8c8780702d13eaee', '日产 轩逸', 'SATHREE', 'nissan', 'richan', '260.00', '260.00', '520.00', 'ZD', '1.6 ', '5', '1', null, 'richan-xuanyi.jpg', null, '1', '黑色 钛金 灰色', null, null);
INSERT INTO `t_company_car` VALUES ('33', '8', '0ac1055474372a3d3', '奔驰 smart', 'SC', 'benz', 'benchismart', '1100.00', '1100.00', '2000.00', 'ZD', '2.0T', '2', '1', null, 'benz_E260L.jpg', null, null, '', null, null);
INSERT INTO `t_company_car` VALUES ('34', '9', '30ae111a14faca15d8', '本田雅阁2.0', 'SATHREE', 'honda', 'bentianyage2.0', '384.00', '384.00', '960.00', 'ZD', '2.0 ', '5', '8', null, 'yage.jpg', null, '0', '黑色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('35', '9', '31afd1a759b61bcdd2', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '400.00', '500.00', '1500.00', 'ZD', '2.5 ', '7', '1', null, 'jac_rf1.jpg', null, '1', '钛灰色 仿皮座椅GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('36', '12', '9e5d813fd0985999', '本田雅阁豪华', 'SATHREE', 'honda', 'bentianyageshushi', '400.00', '450.00', '1300.00', 'ZD', '2.0 ', '5', '3', null, 'yage.jpg', null, '0', '棕色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('37', '13', '3688cf39dfd65bfca37', '本田雅阁2.4', 'SATHREE', 'honda', 'bentianyageshushi', '440.00', '440.00', '1100.00', 'ZD', '2.4 ', '5', '9', null, 'yage.jpg', null, '0', '黑色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('38', '15', '10a49246a57755e', '大众速腾', 'SATHREE', 'volkswagen', 'volkswagen_ST', '304.00', '304.00', '760.00', 'ZD', '1.4T', '5', '3', null, 'volkswagen_suteng1.jpg', null, '1', '灰色 涡轮增压发动机', null, null);
INSERT INTO `t_company_car` VALUES ('39', '17', '90c4260e7337268', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '450.00', '450.00', '1500.00', 'ZD', '2.4 ', '7', '6', null, 'buickluzun.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('40', '18', '35024084349d221', '丰田汉兰达', 'SUV', 'toyota', 'fengtianhanlanda', '500.00', '550.00', '1000.00', 'ZD', '2.0 ', '7', '1', null, 'toyota-puladuo.jpg', null, '1', '全新哦  黑色  导航 赠送全保险', null, null);
INSERT INTO `t_company_car` VALUES ('41', '11', '3d92bc562fbf13f62f', '奔驰 R350', 'CV', 'benz', 'benzR350', '1200.00', '1200.00', '1200.00', 'ZD', '2.4 ', '7', '2', null, 'benz_350.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('42', '10', '3fc7869f81cc611fa20e', '别克首席', 'CV', 'buick', 'biekeshouxi', '700.00', '700.00', '2200.00', 'ZD', '2.4 ', '7', '5', null, 'buickshouxi.jpg', null, '1', '香槟金', null, null);
INSERT INTO `t_company_car` VALUES ('43', '10', '41ff9e0de3f26ebf6df2', '本田 CRV', 'SUV', 'honda', 'CRV', '400.00', '400.00', '800.00', 'ZD', '2.4 ', '5', '2', null, 'bentian-CRV.jpg', null, '1', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('44', '10', '8024d02e450ae22d', '丰田 汉兰达', 'SUV', 'toyota', 'fengtianhanlanda', '550.00', '550.00', '1100.00', 'ZD', '2.7', '5', '2', null, 'toyota_hanlanda.jpg', null, '1', '黑色 真皮座椅 ', null, null);
INSERT INTO `t_company_car` VALUES ('45', '3', '46c7b6434d48dd73', '宝马520', 'SATHREE', 'bmw', 'bmw5', '900.00', '1200.00', '2200.00', 'ZD', '2.0T', '5', '1', null, 'bmw5.jpg', null, '1', '真皮座椅 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('46', '5', '46b767bd342225f15', '别克 凯越', 'SATHREE', 'buick', 'kaiyue', '228.00', '228.00', '550.00', 'ZD', '1.6 ', '5', '0', null, 'buickkaiyue.jpg', null, '1', '自动挡，带导航，倒车影像，皮座椅。', null, null);
INSERT INTO `t_company_car` VALUES ('47', '6', '98eb9b46364f5a8c', '宝马 宝马5', 'SATHREE', 'bmw', 'bmw5', '1000.00', '1000.00', '2000.00', 'ZD', '2.0T', '5', '2', null, 'bmw5.jpg', null, '0', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('48', '8', '4d1d35e4203449eb', '丰田 凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '400.00', '800.00', 'ZD', '2.0 ', '5', '2', null, 'toyota_kaimeirui.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('49', '7', '4976ad75f97f04eb24', '本田CRV', 'SUV', 'honda', 'CRV', '450.00', '500.00', '1450.00', 'ZD', '2.0 ', '5', '3', null, 'bentian-CRV.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('50', '6', '4a84bcea2134e8ed9', '奔驰 E系', 'SATHREE', 'benz', 'benzE', '1000.00', '1000.00', '2000.00', 'ZD', '2.0T', '5', '1', null, 'benz_E320L.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('51', '5', '4b73c4a0a3a452cb7', '宝马320i', 'benchi', 'bmw', '宝马320i', '800.00', '900.00', '1600.00', 'ZD', '2.0 ', '4', '3', null, null, null, '0', '白色 真皮座椅 多功能方向盘 导航', null, null);
INSERT INTO `t_company_car` VALUES ('52', '4', '4c274bda3e53e6f8e', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '350.00', '350.00', '700.00', 'ZD', '1.6 ', '5', '5', null, 'toyota_huaguan.jpg', null, '1', '银色 黑色 红色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('53', '3', '4e86256744542c0b7c', '别克GL8', 'CV', 'buick', 'biekeGL8', '350.00', '400.00', '1600.00', 'ZD', '2.4 ', '7', '6', null, 'buickGL8.jpg', null, '0', '全新车、 蓝色 、银色、GPS 、导航 、 赠送全险、倒车可视。', null, null);
INSERT INTO `t_company_car` VALUES ('54', '2', '4f1743c2881078889', '奔驰 S系', 'SATHREE', 'benz', 'benzS', '1800.00', '1800.00', '3000.00', 'ZD', '3.5 ', '5', '2', null, 'benz-s.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('55', '1', '88ea6f6817f354c3', '奔驰威霆', 'CV', 'benz', 'benchiweiting', '700.00', '800.00', '2400.00', 'ZD', '2.5 ', '9', '5', null, null, null, '0', '银色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('56', '6', '51fb211decec2e1fe67', '丰田 卡罗拉', 'SATHREE', 'toyota', 'fengtiankaluola', '300.00', '300.00', '800.00', 'ZD', '1.6 ', '5', '2', null, 'toyota_kaluola.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('57', '7', '52bbf23c1b57981c062', '丰田 汉兰达', 'SUV', 'toyota', 'fengtianhanlanda', '500.00', '550.00', '1200.00', 'ZD', '2.7', '5', '2', null, 'toyota_hanlanda.jpg', null, '0', '黑色', null, null);
INSERT INTO `t_company_car` VALUES ('58', '9', '5d1ed032b8251225', '别克 GL8-外', 'CV', 'buick', 'buck-GL8-wai', '500.00', '500.00', '1500.00', 'ZD', '2.0 ', '7', '5', null, 'buickGL8.jpg', null, '0', '真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('59', '2', '562780ae62e29901', '奔驰E300', 'SATHREE', 'benz', 'benzE', '1000.00', '1000.00', '2000.00', 'ZD', '3.0 ', '5', '1', null, 'benz_E260L.jpg', null, '1', '黑色 真皮座椅多功能方向盘 GPS导航 定速', null, null);
INSERT INTO `t_company_car` VALUES ('60', '1', '06bf9f02d30b832', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '600.00', '600.00', '1300.00', 'ZD', '2.4 ', '7', '2', null, 'buickluzun.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('61', '4', '949e263642f11d4', '丰田 凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '400.00', '800.00', 'ZD', '2.0 ', '5', '1', null, 'toyota_kaimeirui.jpg', null, '1', '黑色 真皮座椅 ', null, null);
INSERT INTO `t_company_car` VALUES ('62', '5', '59cb8c60a0f74bb3684', '东风 凌志', 'CV', 'dongfeng', 'dongfenglingzhi', '200.00', '400.00', '600.00', 'SD', '1.5', '7', '5', null, 'dongfeng_yj.jpg', null, '1', '真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('63', '8', '5efbba1bd6ed085a', '丰田 卡罗拉', 'SATHREE', 'toyota', 'fengtiankaluola', '300.00', '300.00', '700.00', 'ZD', '1.6 ', '5', '3', null, 'toyota_kaluola.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('64', '3', '9fdb35c45a29cdb0', '起亚 福瑞迪', 'SATHREE', 'kia', 'FURUIDI', '200.00', '200.00', '500.00', 'ZD', '1.6 ', '5', '1', null, 'furuidi.jpg', null, '1', '自动挡，带导航，倒车影像。皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('65', '1', 'fab0644b87db1', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '250.00', '250.00', '600.00', 'ZD', '1.6 ', '5', '1', null, 'toyota_huaguan.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('66', '6', 'acdc489f17797091', '别克 凯越', 'SATHREE', 'buick', 'kaiyue', '200.00', '200.00', '500.00', 'ZD', '1.6 ', '5', '1', null, 'buickkaiyue.jpg', null, '1', '自动挡，带导航，带车影响，皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('67', '10', 'ab27741cd59398e1', '别克路尊', 'CV', 'buick', 'biekeshangwu', '300.00', '300.00', '1500.00', 'ZD', '3.0 ', '7', '0', null, 'buickluzun.jpg', null, '1', '灰色，皮座椅，导航', null, null);
INSERT INTO `t_company_car` VALUES ('68', '12', '1a59b45486c0fad', '别克 君威', 'SATHREE', 'buick', 'junwei', '400.00', '400.00', '800.00', 'ZD', '1.6T', '5', '1', null, 'buickjunwei.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('69', '15', '24bc72ced44a2c8', '大众甲壳虫', 'SC', 'volkswagen', 'dazhongjiakechong', '650.00', '650.00', '1380.00', 'ZD', '2.0 ', '4', '1', null, 'volkswagen_jkc1.png', null, '1', '桔色 米色 金色 真皮座椅 雷达倒车', null, null);
INSERT INTO `t_company_car` VALUES ('70', '11', 'b025ecad12289d9f', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '400.00', '800.00', '1800.00', 'ZD', '2.4 ', '7', '5', null, 'buickluzun.jpg', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('71', '13', '8067ed32a5cff95', '日产轩逸', 'SATHREE', 'nissan', 'fengtianxuanyi', '200.00', '250.00', '600.00', 'ZD', '1.6 ', '5', '20', null, 'richan-xuanyi.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('72', '12', '6f2742fca7667a3a', '日产 阳光', 'SATHREE', 'nissan', 'richan yangguang', '200.00', '200.00', '500.00', 'ZD', '1.4 ', '5', '1', null, 'richan-yangguang.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('73', '15', '6295c0ec76d6e41', '丰田威驰', 'SATHREE', 'toyota', 'weichi', '230.00', '250.00', '500.00', 'ZD', '1.3 ', '5', '2', null, null, null, '0', '新款舒适版，可三亚取车', null, null);
INSERT INTO `t_company_car` VALUES ('74', '17', '68f48fd3cef24d5cc', '别克 首席', 'CV', 'buick', 'biekeshouxi', '500.00', '600.00', '2000.00', 'ZD', '2.4 ', '7', '3', null, 'buickGL8.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('75', '18', '6aede08604fca654f', '大众朗逸', 'SATHREE', 'volkswagen', 'volkswagen_LY', '280.00', '280.00', '700.00', 'ZD', '1.6 ', '5', '4', null, 'volkswagen_langyi1.jpg', null, '0', '黑色 真皮座椅 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('76', '2', '710967ad5e6588ee', '丰田汉兰达', 'SUV', 'toyota', 'fengtianhanlanda', '700.00', '750.00', '1728.00', 'ZD', '2.7', '7', '5', null, 'toyota_hanlanda.jpg', null, '1', '黑色 真皮座椅 雷达倒车', null, null);
INSERT INTO `t_company_car` VALUES ('77', '13', '7b62ebf14883aff85', '别克GL8', 'CV', 'buick', 'biekeGL8', '400.00', '400.00', '1680.00', 'ZD', '2.4 ', '7', '4', null, 'buickGL8.jpg', null, '0', '银色，蓝色今天海口有车', null, null);
INSERT INTO `t_company_car` VALUES ('78', '15', '74873f7468d6d5e0', '丰田汉兰达', 'SATHREE', 'toyota', 'fengtianhanlanda', '500.00', '500.00', '1200.00', 'ZD', '2.4 ', '5', '1', null, 'toyota_hanlanda.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('79', '12', 'b2f76a17183db070', '奔驰唯雅诺', 'CV', 'benz', 'benchi weiyanuo', '900.00', '1000.00', '2600.00', 'ZD', '2.5 ', '7', '5', null, null, null, '0', '黑色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('80', '13', '7976e2c4a41180938', '别克GL8', 'CV', 'buick', 'biekeGL8', '400.00', '400.00', '1500.00', 'ZD', '2.4 ', '7', '10', null, 'buickGL8.jpg', null, '0', '蓝色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('81', '1', '78a693f4028f6cd8bc', '奥迪 A6L', 'SATHREE', 'audi', 'AUDI_A6L', '860.00', '860.00', '860.00', 'ZD', '1.6 ', '5', '8', null, 'audi_A6L.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('82', '11', '7994cbee745d977cd', '本田 凌派', 'SATHREE', 'honda', 'hongdalingpai', '350.00', '500.00', '800.00', 'ZD', '1.8 ', '5', '1', null, 'honda_shiyu.jpg', null, '1', '真皮', null, null);
INSERT INTO `t_company_car` VALUES ('83', '1', '9a976bb098c1b3cf', '宝马 宝马7系', 'SATHREE', 'bmw', 'bm_7x', '1800.00', '1800.00', '3000.00', 'ZD', '3.0 ', '5', '1', null, '', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('84', '1', '7b4e8a287cbde4123c25', '奥迪 A4L', 'SATHREE', 'audi', 'AUDI_AS', '600.00', '600.00', '1200.00', 'ZD', '1.8T', '5', '1', null, 'audi_A4L.jpg', null, '0', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('85', '1', '8968702f2bed59e4', '奔驰 slk200', 'benchi', 'benz', 'benchi', '900.00', '1800.00', '900.00', 'ZD', '1.8T', '2', '1', null, '', null, '0', '红色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('86', '15', '933a7ef882d17cb3', '日产 轩逸', 'SATHREE', 'nissan', 'fengtianxuanyi', '300.00', '300.00', '700.00', 'ZD', '1.6 ', '5', '3', null, 'richan-xuanyi.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('87', '16', '8323548790cedc1ad', '现代悦动', 'SATHREE', 'hyundai', 'xiandaiyuedong', '350.00', '350.00', '758.00', 'ZD', '1.6 ', '5', '0', null, 'hyundai_ruidong1.jpg', null, '1', '银色 黑色 红色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('88', '12', '0ac4372a3d4', '奔驰 smart', 'SC', 'benz', 'benchismart', '300.00', '400.00', '1200.00', 'SD', '1.5T', '6', '12', null, '', null, null, '133-，-', null, null);
INSERT INTO `t_company_car` VALUES ('89', '13', '8528d23f1c9b41187', '大众 朗逸', 'SATHREE', 'volkswagen', 'volkswagen_LY', '230.00', '300.00', '880.00', 'ZD', '1.6 ', '5', '2', null, 'volkswagen_langyi1.jpg', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('90', '17', '8793b75f27cbcc6377', '日产阳光', 'SATHREE', 'nissan', 'richan yangguang', '250.00', '300.00', '600.00', 'ZD', '1.5', '5', '10', null, null, null, '1', '2015年全新车 经济型小车 节油', null, null);
INSERT INTO `t_company_car` VALUES ('91', '4', '8859c999e980f3ca6', '奔驰 S系', 'SATHREE', 'benz', 'benzS', '1800.00', '1800.00', '3600.00', 'ZD', '3.0 ', '5', '1', null, 'benz-s.jpg', null, '0', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('92', '7', '8896c9d80d94adfd2', '奔驰 E系', 'SATHREE', 'benz', 'benzE', '1000.00', '1000.00', '2000.00', 'ZD', '2.0T', '5', '1', null, 'benz_E320L.jpg', null, '0', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('93', '8', '89e9b5b4209b1ba935', '宝马320i', 'benchi', 'bmw', '宝马320i', '1000.00', '1100.00', '2000.00', 'ZD', '2.0 ', '4', '3', null, null, null, '0', '香槟色 真皮座椅 多功能方向盘 导航', null, null);
INSERT INTO `t_company_car` VALUES ('94', '9', '8a1932f088a8e19158f', '丰田 轩逸', 'SATHREE', 'toyota', 'fengtianxuanyi', '300.00', '300.00', '800.00', 'ZD', '1.6 ', '5', '2', null, 'toyota-zhixuan.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('95', '10', '8a2e6e79f7c0d3688', '本田思域', 'SATHREE', 'honda', 'CIVIC', '300.00', '350.00', '850.00', 'ZD', '1.8 ', '5', '3', null, 'bentian-siyu.jpg', null, '0', '红色', null, null);
INSERT INTO `t_company_car` VALUES ('96', '11', '8cb9571ad89843e620', '别克路尊', 'CV', 'buick', 'biekeshangwu', '400.00', '500.00', '1500.00', 'ZD', '2.0 ', '7', '5', null, 'buickluzun.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('97', '6', '8ebb2e93838c37f51a', '宝马z4', 'benchi', 'bmw', 'baoma z4', '1000.00', '1100.00', '2000.00', 'ZD', '2.0 ', '2', '3', null, null, null, '0', '宝石蓝色 真皮座椅 多功能方向盘 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('98', '2', '8d6bef78c8225984310', '丰田 花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '250.00', '250.00', '700.00', 'ZD', '1.6 ', '5', '2', null, 'toyota_huaguan.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('99', '6', '0ac1055424372a3d654', '海马 M5', 'SATHREE', 'haima', 'haimam5', '280.00', '280.00', '1000.00', 'ZD', '1.6T', '5', '1', null, '', null, null, '钛金 真皮座椅 多功能方向盘 定速巡航 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('100', '3', '8ec3ac29d90838cd0e1d', '丰田凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '400.00', '800.00', 'ZD', '2.5 ', '5', '5', null, 'toyota_kaimeirui.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('101', '16', '89af26b3be65181a67', '日产 日产骐达', 'SATWO', 'nissan', 'qida', '228.00', '228.00', '500.00', 'ZD', '1.6 ', '5', '2', null, 'richan-qida.jpg', null, '1', '自动挡，带导航，倒车影像，皮座椅。\n', null, null);
INSERT INTO `t_company_car` VALUES ('102', '2', '8964aacc4a8bd7625', '丰田 埃尔法', 'CV', 'toyota', 'AIERFA', '1050.00', '1050.00', '1050.00', 'ZD', '2.4 ', '7', '2', null, 'toyota_aierfa.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('103', '3', '1aef90965a7939903', '奥迪 A6L-外', 'SATHREE', 'audi', 'audi-a6L-wai', '800.00', '1000.00', '2000.00', 'ZD', '1.6 ', '5', '3', null, '', null, '0', '豪华款', null, null);
INSERT INTO `t_company_car` VALUES ('104', '4', 'c8be36568c1131c21', '丰田凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '400.00', '700.00', 'ZD', '2.0 ', '5', '16', null, 'toyota_kaimeirui.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('105', '6', '7b58ac40eb7fde680', '本田 飞度', 'SATWO', 'honda', 'FIT', '200.00', '200.00', '400.00', 'ZD', '1.3 ', '5', '2', null, '', null, '0', '舒适版，二厢，可三亚取车', null, null);
INSERT INTO `t_company_car` VALUES ('106', '8', '688bf04a0bdd144d7', '奥迪A6', 'SATHREE', 'audi', 'AUDI_A6L', '720.00', '720.00', '1800.00', 'ZD', '2.0 ', '5', '2', null, 'audi_A6L.jpg', null, '0', '黑色 真皮座椅 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('107', '1', '9846468c1fca57f', '丰田凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '400.00', '400.00', '500.00', 'ZD', '2.5 ', '5', '5', null, 'toyota_kaimeirui.jpg', null, '0', '黑色 导航 真皮 巡航 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('108', '8', '99291525c395b880e0', '丰田 考斯特豪华', 'zhongba', 'toyota', 'toyota-costahaohua', '1500.00', '1500.00', '1500.00', 'ZD', '3.5 ', '13', '2', null, 'toyota-kesida.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('109', '5', '99b6d5eee51a6e802', '本田艾力绅', 'CV', 'honda', 'ailishen', '600.00', '600.00', '1300.00', 'ZD', '2.5 ', '7', '1', null, 'ailishen.jpg', null, '1', '白色 真皮座椅 多功能方向盘 多媒体导航定速', null, null);
INSERT INTO `t_company_car` VALUES ('110', '9', '97e90f07e6dc250f', '本田 雅阁豪华', 'SATHREE', 'honda', 'bentianyageshushi', '350.00', '350.00', '350.00', 'ZD', '1.6 ', '5', '4', null, 'yage.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('111', '2', '9bee50bf331002298', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '300.00', '350.00', '1200.00', 'ZD', '3.0 ', '7', '10', null, 'buickluzun.jpg', null, '1', '导航，真皮座椅，倒车影像', null, null);
INSERT INTO `t_company_car` VALUES ('112', '6', '8efd68e1039a3a53', '别克 君越', 'SATHREE', 'buick', 'junyue', '280.00', '350.00', '900.00', 'ZD', '2.4 ', '5', '2', null, 'buickjunwei.jpg', null, '1', '导航，真皮座椅，倒车影像，车况非常好', null, null);
INSERT INTO `t_company_car` VALUES ('113', '2', '856d57c5735cd7', '丰田 考斯特含驾', 'zhongba', 'toyota', 'toyota-costa', '1000.00', '1000.00', '1000.00', 'ZD', '3.5 ', '23', '1', null, 'toyota-kesida.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('114', '8', '94c60eef0a065e4d', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '280.00', '280.00', '1050.00', 'ZD', '2.4 ', '11', '5', null, 'jac_rf1.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('115', '3', 'a6931a90cc1e2885', '大众迈腾', 'SATHREE', 'volkswagen', 'METONG', '500.00', '500.00', '1000.00', 'ZD', '1.8 ', '5', '5', null, 'volkswagen_maiteng.jpg', null, '1', '黑色 真皮座椅 多功能方向盘GPS导航定速', null, null);
INSERT INTO `t_company_car` VALUES ('116', '9', '0b1371942c189f34f', '雪佛兰爱唯欧', 'SATHREE', 'chevrolet', 'xuefulanaiweiou', '218.00', '400.00', '450.00', 'ZD', '1.4 ', '5', '20', null, null, null, '1', '普通座椅 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('117', '3', '9544a9df35fe7137', '丰田 威驰', 'SATWO', 'toyota', 'weichi', '250.00', '250.00', '600.00', 'ZD', '1.6 ', '5', '3', null, 'toyota_weichi.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('118', '1', 'a395cabb3f3d5baaf', '本田CRV', 'SUV', 'honda', 'CRV', '400.00', '450.00', '1100.00', 'ZD', '2.0 ', '5', '5', null, null, null, '1', '舒适 视野开阔 节油', null, null);
INSERT INTO `t_company_car` VALUES ('119', '11', 'a385d57c58b3eaff3', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '260.00', '300.00', '750.00', 'ZD', '1.6 ', '5', '1', null, 'toyota_huangguan1.jpg', null, '0', '白色', null, null);
INSERT INTO `t_company_car` VALUES ('120', '16', 'a3c5a9c1913a7fa761f2', '别克 GL8', 'CV', 'buick', 'biekeGL8', '650.00', '1200.00', '2000.00', 'ZD', '2.4 ', '7', '1', null, '', null, '1', '真皮', null, null);
INSERT INTO `t_company_car` VALUES ('121', '12', 'a5b56222643882da3', '本田CRV', 'SATHREE', 'honda', 'CRV', '450.00', '450.00', '1200.00', 'ZD', '2.4 ', '5', '1', null, 'honda_CRV1.jpg', null, '1', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('122', '3', 'a7523b7eb9766d7f8', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '350.00', '450.00', '1300.00', 'SD', '2.4 ', '12', '4', null, 'jac_rf1.jpg', null, '0', '银色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('123', '3', 'aa49bd1c2fbd1c0111', '丰田凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '500.00', '500.00', '1000.00', 'ZD', '2.0 ', '5', '5', null, 'toyota_kaimeirui.jpg', null, '1', '黑色 真皮座椅 雷达倒车', null, null);
INSERT INTO `t_company_car` VALUES ('124', '3', '0ac1372a3d564654', '日产帕拉丁', 'SUV', 'nissan', 'PALADING', '440.00', '440.00', '1100.00', 'SD', '2.0 ', '5', '6', null, 'nissan_palading.jpg', null, null, '灰色', null, null);
INSERT INTO `t_company_car` VALUES ('125', '4', 'ac3b9f7a737827cca3b', '宝马 宝马X5', 'SUV', 'bmw', 'bmwx5', '1200.00', '1400.00', '2400.00', 'ZD', '2.0T', '5', '2', null, 'bmwx5.jpg', null, '1', '导航，真皮座椅，倒车影像，车况非常好', null, null);
INSERT INTO `t_company_car` VALUES ('126', '6', 'bc7f404275675efd', '奔驰 smart', 'CV', 'benz', 'benchismart', '248.00', '248.00', '500.00', 'ZD', '1.2', '2', '2', null, 'benz_SMART1.jpg', null, '1', '13年，自动挡，带导航，皮座椅，车况极好非常新。\n', null, null);
INSERT INTO `t_company_car` VALUES ('127', '6', 'ad7f3b1774f591c1df5d6', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '350.00', '400.00', '1300.00', 'ZD', '2.4 ', '11', '3', null, 'jac_rf1.jpg', null, '0', '银色 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('128', '8', 'aff2bbfada6d53f811d', '别克GL8', 'SATHREE', 'buick', 'biekeGL8', '500.00', '500.00', '2000.00', 'ZD', '2.5 ', '7', '1', null, 'buickGL8.jpg', null, '1', '精英款 钛灰色多媒体导航', null, null);
INSERT INTO `t_company_car` VALUES ('129', '9', 'bdf3df4373b065ee', '三菱翼神', 'SATHREE', 'mitsubishi', 'YISHEN', '320.00', '320.00', '800.00', 'ZD', '1.8 ', '5', '1', null, 'mitsubishi_yishen.jpg', null, '0', '黑色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('130', '12', 'b0f4c7e18b9d86e97cf', '进口大众高尔夫敞篷', 'SATHREE', 'volkswagen', 'GOLF', '700.00', '800.00', '1000.00', 'ZD', '1.4T', '4', '1', null, 'volkswagen_gaoerfu.jpg', null, '1', '真皮座椅 GPS导航 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('131', '13', 'b17a968561115082', '现代 ix35', 'SATHREE', 'hyundai', 'xiandaiix35', '400.00', '800.00', '980.00', 'ZD', '1.6 ', '5', '1', null, '', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('132', '16', 'b2765ad0186622c77', '本田 艾力绅', 'SATHREE', 'honda', 'ailishen', '650.00', '1200.00', '2000.00', 'ZD', '2.4 ', '7', '1', null, 'ailishen.jpg', null, '1', '真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('133', '12', 'b21deeb224d0972f05', '现代 索纳塔', 'SATHREE', 'hyundai', 'SONATA', '320.00', '380.00', '1200.00', 'ZD', '2.0T', '5', '2', null, 'hyundai_suonata8.jpg', null, '1', '导航，真皮座椅，倒车影像，车况非常好', null, null);
INSERT INTO `t_company_car` VALUES ('134', '3', 'b22a27e83597ed52b', '现代名图', 'SATHREE', 'hyundai', 'xiandaimingtu', '300.00', '300.00', '700.00', 'ZD', '1.8 ', '5', '2', null, 'hyundai_mingtu.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('135', '16', 'b7c407e6a71280f62', '现代悦动', 'SATHREE', 'hyundai', 'xiandailangdong', '250.00', '250.00', '500.00', 'ZD', '1.6 ', '5', '2', null, 'hyundai_ruina1.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('136', '18', 'b668f3d5f30fb6ed', '本田CRV', 'SUV', 'honda', 'CRV', '400.00', '400.00', '800.00', 'ZD', '2.0 ', '5', '2', null, 'honda_CRV1.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('137', '12', 'bf5b934228743578ac9', '丰田卡罗拉', 'SATHREE', 'toyota', 'fengtiankaluola', '250.00', '700.00', '700.00', 'ZD', '1.6 ', '5', '1', null, null, null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('138', '3', 'cec5100cdb405787', '大众途观', 'SUV', 'volkswagen', 'volkswagen_TG', '500.00', '550.00', '1500.00', 'ZD', '2.0 ', '5', '3', null, 'volkswagen_tuan1.jpg', null, '0', '白色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('139', '16', 'c35fd8d140dfcd6f291', '丰田 凯美瑞', 'SATHREE', 'toyota', 'fengtiankaimeirui', '350.00', '400.00', '800.00', 'ZD', '2.0T', '5', '12', null, 'toyota_kaimeirui.jpg', null, '1', '导航，真皮座椅，倒车影像，车况非常好，15年新款', null, null);
INSERT INTO `t_company_car` VALUES ('140', '2', '38efe7f409c80ec1e', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '250.00', '250.00', '600.00', 'ZD', '1.6 ', '5', '5', null, 'toyota_huangguan1.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('141', '7', 'cb56eaf6e39b62b8c', '大众甲壳虫', 'benchi', 'volkswagen', 'dazhongjiakechong', '550.00', '600.00', '1200.00', 'ZD', '2.0 ', '4', '3', null, 'volkswagen_jkc1.png', null, '0', '米白色 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('142', '10', 'c52b37ea624666844', '丰田RAV4', 'SUV', 'toyota', 'RAV4', '400.00', '400.00', '800.00', 'ZD', '2.0 ', '5', '2', null, 'toyota_RAV4.jpg', null, '0', '白色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('143', '11', 'a4e2beafad842c51', '别克 GL8', 'CV', 'buick', 'biekeGL8', '350.00', '350.00', '350.00', 'ZD', '2.4 ', '7', '12', null, 'buickGL8.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('144', '10', 'c945e8ebaf45fc70b', '别克 路尊', 'CV', 'buick', 'biekeshangwu', '500.00', '500.00', '1800.00', 'ZD', '2.4 ', '7', '1', null, 'buickluzun.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('145', '10', 'c80bbcc34baf25fbaac', '本田CRV', 'SUV', 'honda', 'CRV', '550.00', '550.00', '1188.00', 'ZD', '2.0 ', '5', '5', null, 'honda_CRV1.jpg', null, '1', '白色 黑色 真皮座椅 雷达倒车 部分有导航', null, null);
INSERT INTO `t_company_car` VALUES ('146', '10', '0ac105544372a3dhiuh', '别克 君威', 'SATHREE', 'buick', 'junwei', '360.00', '360.00', '900.00', 'ZD', '1.8 ', '5', '1', null, 'buickjunwei.jpg', null, null, '', null, null);
INSERT INTO `t_company_car` VALUES ('147', '12', 'bdfea11378bc1448', '现代悦动', 'SATHREE', 'hyundai', 'xiandaiyuedong', '260.00', '300.00', '750.00', 'SD', '1.8 ', '5', '1', null, null, null, '0', '黑色', null, null);
INSERT INTO `t_company_car` VALUES ('148', '13', 'cc3982a229823437933', '奔驰 smart', 'SATWO', 'benz', 'benchismart', '398.00', '500.00', '800.00', 'ZD', '1.0', '2', '5', null, 'benz_SMART1.jpg', null, '1', '真皮', null, null);
INSERT INTO `t_company_car` VALUES ('149', '16', '6a516c7a4f4060784', '别克 君越', 'SATHREE', 'buick', 'junyue', '400.00', '400.00', '608.00', 'ZD', '2.0 ', '5', '1', null, '', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('150', '7', 'cc3da0fa98e9c5b1329f', '丰田 花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '250.00', '300.00', '600.00', 'ZD', '1.6 ', '5', '3', null, 'toyota_huaguan.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('151', '12', 'dc98287c50fcef8d4c', '大众 捷达', 'SATHREE', 'volkswagen', 'JIEDA', '230.00', '300.00', '880.00', 'ZD', '1.6 ', '5', '2', null, 'volkswagen_jieda1.jpg', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('152', '14', 'cbb4eb3e89eff4e380', '北汽 北汽E级', 'SATHREE', 'beiqi', 'beiqE', '198.00', '350.00', '400.00', 'ZD', '1.5', '5', '3', null, '', null, '1', '真皮', null, null);
INSERT INTO `t_company_car` VALUES ('153', '6', 'cffe22a987d7599927', '丰田霸道', 'SUV', 'toyota', 'fengtianbadao', '1200.00', '1300.00', '2918.00', 'ZD', '2.7', '5', '3', null, 'toyota_bd1.jpg', null, '1', '白色 军绿色 真皮座椅 雷达倒车', null, null);
INSERT INTO `t_company_car` VALUES ('154', '12', 'd4157dc569aac8302', '宝马 宝马5', 'SATHREE', 'bmw', 'bmw5', '1000.00', '1000.00', '2000.00', 'ZD', '2.0T', '5', '2', null, 'bmw5.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('155', '14', 'd4a31c75553f5a4a5', '长安奔奔', 'SATWO', 'changan', 'changanbenben', '98.00', '200.00', '250.00', 'SD', '1.0', '5', '0', null, 'changan_benben1.jpg', null, '0', '真皮座椅 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('156', '16', '80492d21d8f3ec6c', '丰田卡罗拉', 'SATHREE', 'toyota', 'fengtiankaluola', '260.00', '300.00', '600.00', 'ZD', '1.6 ', '5', '5', null, 'toyota_kaluola.jpg', null, '1', '黑色 真皮座椅的', null, null);
INSERT INTO `t_company_car` VALUES ('157', '12', 'd5218556d3a9f7031', '丰田锐志', 'SATHREE', 'toyota', 'ruizhi', '400.00', '400.00', '800.00', 'ZD', '2.5 ', '5', '5', null, 'toyota_ruizhi.jpg', null, '0', '黑色 真皮座椅 多功能方向盘', null, null);
INSERT INTO `t_company_car` VALUES ('158', '3', '98a8cfd30c2131eb', '奔驰 E系', 'SC', 'benz', 'benzE', '9999.00', '9999.00', '9999.00', 'SD', '3.6 ', '5', '2', null, 'benz_E320L.jpg', null, '0', '測試車輛', null, null);
INSERT INTO `t_company_car` VALUES ('159', '5', 'd914d72eced240ff', '别克 首席', 'CV', 'buick', 'biekeshouxi', '500.00', '500.00', '1800.00', 'ZD', '2.4 ', '7', '3', null, 'buickshouxi.jpg', null, '1', '自动挡，皮座椅。倒车雷达。', null, null);
INSERT INTO `t_company_car` VALUES ('160', '6', '0ac10554372a3d8523', '别克 君威', 'SATHREE', 'buick', 'junwei', '350.00', '350.00', '1200.00', 'ZD', '2.5 ', '5', '1', null, 'buickjunwei.jpg', null, null, '黑色 真皮座椅 多功能方向盘 定速巡航 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('161', '8', 'ddf682032219a6ab1', '丰田 威驰', 'SATHREE', 'toyota', 'fengtianweichi', '250.00', '250.00', '700.00', 'ZD', '1.4 ', '5', '2', null, 'toyota_weichi.jpg', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('162', '2', 'de64c7bbc41849b73cd', '本田 飞度', 'SATWO', 'honda', 'FIT', '230.00', '230.00', '460.00', 'ZD', '1.5', '5', '1', null, '', null, '0', '新款飞度', null, null);
INSERT INTO `t_company_car` VALUES ('163', '12', 'b6667f3efdeded28', '起亚K2', 'SATHREE', 'kia', 'K2', '198.00', '350.00', '400.00', 'ZD', '1.4 ', '5', '20', null, 'qiya_K2.jpg', null, '1', '真皮座椅 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('164', '9', 'df5b5d7ed4dd2600a', '本田 雅阁', 'SATHREE', 'honda', 'YAGE', '400.00', '400.00', '600.00', 'ZD', '2.0 ', '5', '1', null, 'bentian-yage.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('165', '2', 'df8c3ed4f69212128a4', '雪弗兰 爱唯欧', 'SATWO', 'chevrolet', 'xuefulanaiweiou', '200.00', '200.00', '500.00', 'ZD', '1.4 ', '5', '3', null, '', null, '1', '', null, null);
INSERT INTO `t_company_car` VALUES ('166', '4', 'e05f345c5b18ef71279', '宝马宝马5', 'SATHREE', 'bmw', 'bmw5', '1000.00', '1200.00', '1000.00', 'ZD', '2.0 ', '5', '10', null, 'bmw5.jpg', null, '1', '高贵上档次 舒适 节能', null, null);
INSERT INTO `t_company_car` VALUES ('167', '6', 'e178b9fbc6cbc9faf82', '别克GL8', 'CV', 'buick', 'biekeGL8', '350.00', '450.00', '1600.00', 'ZD', '2.4 ', '7', '10', null, 'buickGL8.jpg', null, '0', '', null, null);
INSERT INTO `t_company_car` VALUES ('168', '1', 'e27d7756eb994f568fc', '本田 奥德赛', 'CV', 'honda', 'aodesai', '360.00', '900.00', '1800.00', 'ZD', '2.4 ', '7', '0', null, 'aodesai.jpg', null, '0', '真皮座椅 多功能方向盘 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('169', '12', 'e65112505ccaef858e', '别克首席', 'CV', 'buick', 'biekeshouxi', '550.00', '650.00', '2200.00', 'ZD', '2.4 ', '7', '5', null, 'buickshouxi.jpg', null, '0', '银色 真皮座椅 多功能方向盘 GPS导航 定速巡航 天窗', null, null);
INSERT INTO `t_company_car` VALUES ('170', '13', 'e817e023dc6479eacf', '别克GL8', 'SATHREE', 'buick', 'biekeGL8', '550.00', '550.00', '2000.00', 'ZD', '2.5 ', '7', '1', null, 'buickGL8.jpg', null, '1', '钛灰色 真皮座椅 多功能方向盘 多媒体导航定速', null, null);
INSERT INTO `t_company_car` VALUES ('171', '16', 'ea0757a98c8633cfc3b', '奥迪 A6L', 'SATHREE', 'audi', 'AUDI_A6L', '800.00', '800.00', '1600.00', 'ZD', '2.0T', '5', '3', null, 'audi_A6L.jpg', null, '0', '黑色 真皮座椅 多功能方向盘 定速巡航', null, null);
INSERT INTO `t_company_car` VALUES ('172', '2', 'eaf1f52c0bff9992d233c', '奥迪 A6L', 'SATHREE', 'audi', 'AUDI_A6L', '700.00', '1800.00', '2380.00', 'ZD', '2.4 ', '5', '1', null, 'audi_A6L.jpg', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('173', '16', 'f204a0f051b7f157db20', '丰田花冠', 'SATHREE', 'toyota', 'fengtianhuaguan', '230.00', '280.00', '500.00', 'ZD', '1.6 ', '5', '30', null, 'toyota_huaguan.jpg', null, '0', '卓越版 黑色 银色 真皮座椅今天海口有车', null, null);
INSERT INTO `t_company_car` VALUES ('174', '6', 'f789eccd5fe5790c1f', '奔驰 smart', 'SATWO', 'benz', 'benchismart', '288.00', '288.00', '600.00', 'ZD', '1.2', '2', '2', null, 'benz_SMART1.jpg', null, '1', '自动挡，带导航，皮座椅，新车', null, null);
INSERT INTO `t_company_car` VALUES ('175', '3', 'f3b98de52024cf7bd1c', '大众POLO', 'SATWO', 'volkswagen', 'POLO', '200.00', '200.00', '600.00', 'ZD', '1.4 ', '5', '3', null, 'volkswagen_POLO.jpg', null, '1', '红色，皮座椅，导航', null, null);
INSERT INTO `t_company_car` VALUES ('176', '2', 'f447f5144d39193cb', '江淮瑞风', 'CV', 'jac', 'jianghuairuifeng', '350.00', '400.00', '1000.00', 'ZD', '2.8 ', '9', '2', null, 'jac_rf1.jpg', null, '0', '柴油 银色 多功能方向盘 赠送全险', null, null);
INSERT INTO `t_company_car` VALUES ('177', '7', 'f61fcf372bd599993', '现代 名图', 'SATHREE', 'hyundai', 'xiandaimingtu', '280.00', '480.00', '980.00', 'ZD', '1.6 ', '5', '1', null, '', null, '1', '真皮座椅 多功能方向盘 GPS导航 定速巡航 ', null, null);
INSERT INTO `t_company_car` VALUES ('178', '7', 'f822ed20ca2da51fdb7c1', '本田 杰德', 'SATWO', 'honda', 'hongdajiede', '350.00', '500.00', '800.00', 'ZD', '1.8 ', '5', '5', null, 'honda_shiyu.jpg', null, '1', '真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('179', '7', 'f38d8f7c9e4a711d', '别克GL8', 'CV', 'buick', 'biekeGL8', '550.00', '550.00', '1800.00', 'ZD', '2.4 ', '7', '5', null, 'buickGL8.jpg', null, '0', '银色 宝蓝 真皮座椅', null, null);
INSERT INTO `t_company_car` VALUES ('180', '7', 'f9403a76e1403e42d', '东风景逸', 'SATWO', 'dongfeng', 'JY', '198.00', '350.00', '400.00', 'ZD', '1.5', '5', '3', null, 'dongfeng_yj.jpg', null, '1', '真皮座椅 GPS导航', null, null);
INSERT INTO `t_company_car` VALUES ('181', '7', 'faa9fa56ace6e94da2f8', '别克 首席', 'CV', 'buick', 'biekeshouxi', '400.00', '450.00', '2000.00', 'ZD', '2.4 ', '7', '10', null, 'buickshouxi.jpg', null, '1', '导航，真皮座椅，倒车影像，车况非常好', null, null);
INSERT INTO `t_company_car` VALUES ('182', '9', 'faaafe7a6b7421baba4', '雪弗兰赛欧', 'SATWO', 'chevrolet', 'saiou', '200.00', '200.00', '500.00', 'ZD', '1.2', '5', '0', null, null, null, '1', '黄色，皮座椅，导航', null, null);
INSERT INTO `t_company_car` VALUES ('183', '11', 'fb34646d99f3886b696', '丰田 威驰', 'SATHREE', 'toyota', 'fengtianweichi', '220.00', '300.00', '600.00', 'ZD', '1.6 ', '5', '10', null, '', null, '1', '倒车影像，导航，行车记录仪', null, null);
INSERT INTO `t_company_car` VALUES ('184', '3', 'fc7c37867b33acc2ad5', '雪弗兰赛欧', 'SATHREE', 'chevrolet', 'saiou', '200.00', '200.00', '400.00', 'ZD', '1.2', '5', '0', null, null, null, '1', '黄色，皮座椅，导航', null, null);
INSERT INTO `t_company_car` VALUES ('185', '4', 'ff1ce8f30d7b5e12a23c', '奥迪A6', 'SATHREE', 'audi', 'AUDI_A6L', '800.00', '800.00', '1800.00', 'ZD', '2.0 ', '5', '6', null, 'audi_A6L.jpg', null, '1', '黑色 真皮座椅 多功能方向盘GPS导航 定速', null, null);

-- ----------------------------
-- Table structure for t_lease_address
-- ----------------------------
DROP TABLE IF EXISTS `t_lease_address`;
CREATE TABLE `t_lease_address` (
  `id` varchar(32) NOT NULL,
  `lease_id` varchar(32) default NULL COMMENT '租赁商id',
  `lease_province` varchar(32) default NULL,
  `lease_city` varchar(32) default NULL,
  `lease_address` varchar(500) default NULL COMMENT '详细地址',
  `lease_state` int(11) default NULL COMMENT '借还状状',
  `create_date` datetime default NULL,
  `lease_area` varchar(32) default NULL,
  `platform_address_id` varchar(32) default NULL,
  `briefName` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `t_lease_address_platform_addressId` (`lease_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租赁商通借通还地址';

-- ----------------------------
-- Records of t_lease_address
-- ----------------------------
INSERT INTO `t_lease_address` VALUES ('011bb734aa80453ab0dbfb53e9ecb98b', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号', '0', '2015-01-21 04:37:07', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('03bab33c7a584030919a6f62c4d5016b', '533fb89cacee47b69d6ca6c997d56721', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-16 20:42:14', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('052a75788c44496a8746951c36c90bcc', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-03-01 12:07:15', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('0888e8a6200749deb212b7944d9fb9a1', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-21 04:37:07', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('0890d3fe86de4558aa04a4b5edf006ba', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-13 17:09:16', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('0b784cfa1b3d4417a9d077906892fa65', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-04 23:19:53', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('0b829d8ea55047588bf470a85b8f54f9', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-29 23:37:53', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('0cbc9c83c4bc4bb28aa7d7aadf3d1d4a', 'fef8041c9811457c86fbaca1a2f9ba46', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-08 17:37:09', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('0d28f5e6c72747feb29a8c143d5e5693', '084d32a81bdf45df82fe82eabf00a9a1', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-24 10:53:02', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('10973da9f7ea482da4eaa92280282477', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-23 18:23:02', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('11200efeb5c0421fa111c26e7b4ce981', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-09 18:11:55', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('11cf5d6d294b4c8aab5145f7d11d960d', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-03-01 12:07:15', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('167dd0dec6c24fcaac9be1526ff78b88', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-09 18:11:55', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('1707a85070eb4b8681fe6924d040dfe5', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-23 18:23:02', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('1804e5ca7b994ec6bed84652d78922b4', 'cd3a0df2892b4200a4eaf6c925d2169b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-03 16:23:40', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('1dc141fb8465467687ae8cf0f06e1015', 'a03d682d6fea4ae4adba650461976621', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-02 16:38:55', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('1feaf90d7e324aca95255cbd31e21ecb', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-03-01 12:08:27', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('20c72a22f1e740e68a2d752289eea7f1', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-21 04:37:07', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('266f75ec60794f14bfe756dedbc70780', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-03-01 12:07:15', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('2927655db0c945eba0b2e6e0e04396f3', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-03-01 12:08:27', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('29a47ffba2fd480eaef05afda67ddcc7', '645b0d1f025a4486923b01730fc82e7b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-09 17:58:11', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('2ac46c3602434781984fc9cd5899085c', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-09 18:11:55', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('2b8b3f77f39f4d78b4fe827c200b3500', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-03-01 12:07:15', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('2d8cfd8eebf34723ab92b945deae4277', '501296d29a5e42b7a2e5aa1f1a13f77f', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-03 12:14:42', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('2ffc3e8a03b545e29e720e2499d70fc0', 'a03d682d6fea4ae4adba650461976621', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-02 16:38:55', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('32150c96876d41f098ea4b3c1c6819e6', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-01-29 23:37:53', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('328987bd653b43dc88a9c6818228574f', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-21 03:33:08', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('4065ae286404433e9b8be9b7c7efc0d5', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-03-01 12:07:15', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('407fe215edf24ee684d5574ce19423e9', '645b0d1f025a4486923b01730fc82e7b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-09 17:58:11', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('431d33544c62480fa94e2f8a447ec86a', '08f6e371b8d14d15871f4068a57f70c5', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-28 11:32:05', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('44c1deba94c647db9f2e4e48d2f29396', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-13 17:09:16', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('45bccca949c442d4bfc48ccbdaaafa4a', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-09 18:11:55', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('461b57af457b45d2b56e45403840fbcd', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号', '0', '2015-01-21 03:33:08', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('46dcffca8d2142c0ac2c30f59fcbde04', '559aedce220247109c18afa0aad97e63', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-24 08:04:45', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('49244fcecd38455ca5ffd2c4570345ad', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-03-01 12:08:27', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('4acb78e50e2c4cf2b6a434c3b06398f0', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-03-01 12:08:28', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('4c2309b5799547f2a8930e3d16d55ae7', '08f6e371b8d14d15871f4068a57f70c5', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-28 11:32:05', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('4ef65a27969b435ca43f25244424b937', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-13 17:09:16', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('50da269f1bd94590ad9508604d7e6109', '1630d919ae0346118f5be74ef1b449f8', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-13 17:06:44', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('522662680aea4df1bc133d8cd5304f87', '084d32a81bdf45df82fe82eabf00a9a1', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-24 10:53:02', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('52c6bd0f09a644a58e1f37c7ab0ceafd', 'f922846e30df44459b6c2a7f914ed9eb', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-02 16:37:33', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('56e9ed931ca04e6199abf5d8ef158698', 'fd0c62e8dfd7480ca4bdd6d23489e0da', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-16 13:45:40', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('57fa47268c8643f683b5558964e43dae', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '0', '2015-01-21 03:33:08', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('58ad563cdbc442139a14ee21a9c80aac', '1630d919ae0346118f5be74ef1b449f8', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-13 17:06:44', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('5bbe8fd75a9245fea7e462941ef831bb', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-23 18:23:02', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('5d38befaf9564664bdc3f05c41fdcb03', 'fef8041c9811457c86fbaca1a2f9ba46', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-08 17:37:09', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('625e977aaf6740809c9d60879072256b', '08f6e371b8d14d15871f4068a57f70c5', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-28 11:32:05', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('64631a2cc46e4e40a34ecf7b90543b0d', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-29 23:37:53', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('66013f096da342ae908f5ad5cd4653f4', '645b0d1f025a4486923b01730fc82e7b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-09 17:58:11', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('676bd1de9b68442bab069de39ba752a0', '0e25b4cd27e94bb6a613839216163c01', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-23 08:13:44', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('68372fe781434f2a8686e594ad81259a', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-03-01 12:07:15', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('686fd410f3b34f66a5baf5f10be50423', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-21 04:37:07', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('6a5abbeba5ed410eb6235742ebb55c92', '01a249120f544fc69420c264c1238a8c', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-24 08:48:42', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('6d9ad7496d134b198a370c92b31cd221', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-23 18:23:02', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('6fc19c222dff40239f89482efaa11928', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-13 17:09:16', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('70f97077a0e143348a5d673dde56e889', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-03-01 12:08:27', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('7182a8ab43134dc6b84a04ec22631739', '533fb89cacee47b69d6ca6c997d56721', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-16 20:42:14', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('73e3609b6d7f4393971c92fdd8d68809', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-13 17:09:16', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('75fdeb9c9dda4884adebfb17152f6df2', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '0', '2015-01-21 04:37:06', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('78e9277dfd5c49beb64c7b5a71782504', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号（海航文化广场旁）', '0', '2015-01-29 23:37:11', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('7b4d922884ae4bc5a2cd1403e8def09b', '559aedce220247109c18afa0aad97e63', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-24 08:04:45', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('7d6ca257ee8345799feaff328b14fa95', 'a03d682d6fea4ae4adba650461976621', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-02 16:38:55', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('805c28b2e59f44189879c7585b3df657', 'f922846e30df44459b6c2a7f914ed9eb', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-02 16:37:33', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('82b8aa1a27724e3487c34f1d54caf34e', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-21 03:33:08', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('85eaecb968af4788a9553a60450e8d5c', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号（海航文化广场旁）', '0', '2015-01-29 23:37:11', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('8614075d7a7b44eb849b72663e8b95f8', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-09 18:11:55', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('86746b8c009f42bdb4a935b3f9059c26', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-23 18:23:02', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('86889cd8ba594b28ba3241d818b92685', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号（海航文化广场旁）', '0', '2015-01-29 23:37:53', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('8a04f385a85a41febd24617a524637f5', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-04 23:19:53', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('8ab27fb0380b43ecbc3e9271a0e7df79', 'ac9d67f0f6f24e00a412e76f95ab4684', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-04 14:24:14', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('8b69f9cce3da47308d0f30c8b9e5bd30', '0e25b4cd27e94bb6a613839216163c01', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-23 08:13:44', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('8c49c8a7524449c2b9155cc2ec26c7ba', '501296d29a5e42b7a2e5aa1f1a13f77f', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-03 12:14:42', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('8d7bd9fcb075499ab0a61b9a86fe671d', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-03-01 12:08:28', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('8f678483d2f34938927a0ff76f8ab625', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-04 23:19:53', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('9024a587a4a04e118532d34565e6ff5b', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-13 17:09:16', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('93ed79240e3b41ccaed317ff083206b7', '0e25b4cd27e94bb6a613839216163c01', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-23 08:13:44', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('95a439bc1f5a423b85470a5ab71a52fb', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-01-29 23:37:11', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('963e35dba08940258fef2a8a29debfcb', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '0', '2015-01-21 04:37:07', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('97dd3c4b106d4d6285000cc2f2aa5817', '084d32a81bdf45df82fe82eabf00a9a1', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-24 10:53:02', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('98fa255c21f64e2daea4e2eb6c3535d5', 'ac9d67f0f6f24e00a412e76f95ab4684', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-04 14:24:14', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('99b0e8204dbe4122add839b3843fcf26', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-03-01 12:08:27', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('9fc11d3c9dea4eb39d7fc704adb41faa', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-04 23:19:53', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('a256443d627041bd99c6f358647efb0b', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-09 18:11:55', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('a262cd26fe1843ba9390c252c506f948', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号', '0', '2015-01-21 03:33:08', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('a36e1eb49a884ec2994f63c0e37e9321', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-04 23:19:53', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('a481d0f3f5e04db09ef7c29e99e3a7f1', 'fef8041c9811457c86fbaca1a2f9ba46', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-08 17:37:09', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('a532a216146a493f8c04bcc73fbabfe9', '01a249120f544fc69420c264c1238a8c', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-24 08:48:42', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('a5ec7d84b0114ab88b45141b2817032d', 'fd0c62e8dfd7480ca4bdd6d23489e0da', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-16 13:45:40', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('a6a6ff580a33468b83ee2ce11b14939f', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-29 23:37:11', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('ad10bb8109dd450b80cbba30560a22f3', '645b0d1f025a4486923b01730fc82e7b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-09 17:58:11', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('af9b73efa6954998b4250e64f00156d3', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-03-01 12:07:15', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('b0508ee6c16e426497d39ab4c999db5c', '2cdd09bd698a45edaa7777631f0583f0', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-03-01 12:08:28', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('b41a4711d3ad4a5a9f261d16a5d2e86a', '084d32a81bdf45df82fe82eabf00a9a1', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-24 10:53:02', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('b6026132188d42cdad8d6617ca48ec63', '0e25b4cd27e94bb6a613839216163c01', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-23 08:13:44', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('bbc1311b6e4f4cbb8a38e0fd74350f12', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-09 18:11:55', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('bebe4def679d4e0194450bddb2ab81fa', 'cd3a0df2892b4200a4eaf6c925d2169b', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-03 16:23:40', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('bf456727cde54808a7e6d53ab0f23c3f', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-01-29 23:37:11', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('c144e5210b9f4879b815f915cc531b43', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-01-29 23:37:53', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('c3ccbb43b7fd464faab65d18315065be', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-13 17:09:16', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('c5b9285bdfae4e8a9c5653206c429fd8', '70b5c27c005b408f99fa86169f38cf06', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-09 18:11:55', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('c6f4d0201c544410b9acea6761dab5fb', '533fb89cacee47b69d6ca6c997d56721', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-16 20:42:14', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('c786b9317d3344089da9899aea48ce15', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-21 03:33:08', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('c8025473b22a4c1485718dea25b43408', 'f922846e30df44459b6c2a7f914ed9eb', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-02 16:37:33', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('c82a4f2facab4d548d8055c66a6f304d', '559aedce220247109c18afa0aad97e63', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-24 08:04:45', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('c8f06d4dd5c34a00b46118ffbf92fdf8', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '0', '2015-01-21 03:33:08', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('c99548b0f87f42f8ad807b84e17354dc', 'cd3a0df2892b4200a4eaf6c925d2169b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-03 16:23:40', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('caa6e751135148ef95c99b960cb4a455', '01a249120f544fc69420c264c1238a8c', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-24 08:48:41', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('cd1d6b9115bc43cea71b1ee17c1c4181', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-04 23:19:53', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('d09eca6e1f1449cbaef14786b52d595d', '1630d919ae0346118f5be74ef1b449f8', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-13 17:06:44', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('d0ddc6eeac1740108882ed7bad312239', '8e6fda0927744d6d9475172eb4c537e0', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-21 03:33:08', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('d2c19da9170a4dbd940fa6a0c306324b', 'a03d682d6fea4ae4adba650461976621', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-02 16:38:55', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('d52df12d5f2b4f30b09c2611ffff5553', '08f6e371b8d14d15871f4068a57f70c5', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-01-28 11:32:05', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('d82dd19838584fb49e821b1a19b74308', '1630d919ae0346118f5be74ef1b449f8', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-13 17:06:44', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('dd4aeed86ead46cb904bf486a21a1dd8', 'fd0c62e8dfd7480ca4bdd6d23489e0da', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-16 13:45:40', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('deace2c9e84045138d8b39e57b293b0c', '30dfff39d2594a76a78b57c1f37cba75', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号（海航文化广场旁）', '0', '2015-01-29 23:37:53', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('deaf58d110774d31b0444cb4485a6ec1', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-04 23:19:53', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('e6cc5932fd1944ed893b617f12dbd026', 'ac9d67f0f6f24e00a412e76f95ab4684', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-04 14:24:14', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('e6ecaa792aa241cb8d41e68f362645f3', 'fef8041c9811457c86fbaca1a2f9ba46', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-08 17:37:09', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('e73df74517ad4898becc9ef2fda7e169', 'fd0c62e8dfd7480ca4bdd6d23489e0da', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-16 13:45:40', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('e8795f4ad7f645af8e850b560a2edcae', 'ac9d67f0f6f24e00a412e76f95ab4684', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-04 14:24:14', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('e8ef3a1e465a453c9cb4bd03faa4f200', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-21 04:37:07', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('e93d25a1555044cea06c218fbe373b55', 'e30f05144ae64c63a4f4044d896654a0', 'root-37', 'root-37-2', '海南省三亚市凤凰机场到达出口', '0', '2015-01-29 23:37:11', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('eb042a96bf8f4c20b88f8d5c3b00c779', '533fb89cacee47b69d6ca6c997d56721', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-16 20:42:14', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('eb24bd0732a44c22ac9e51dd2cd1facf', '01a249120f544fc69420c264c1238a8c', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-24 08:48:42', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('edf8cd878bd7428fb8ea5fc68a18d8a4', '1403ed639bfc47fdb192d9b368a33daa', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-02-04 23:19:53', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('ee86c936ba1b4dfba1d7dcaa9a2949b1', 'cd3a0df2892b4200a4eaf6c925d2169b', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-03 16:23:40', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('f01df76722054b978c02f8772615a2e0', '501296d29a5e42b7a2e5aa1f1a13f77f', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-03 12:14:42', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('f1111f0ccb574df68cf421d638598a49', '7e8eae25293f4977b48697afe2d7b6ce', 'root-37', 'root-37-1', '海口市美兰区国兴大道2号', '0', '2015-01-21 04:37:07', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('f1f0407903e049739cf4a3c5fbef7de5', '55df8c7529af4beba4d037f20fcd646b', 'root-37', 'root-37-1', '海口国兴大道2号（海航文化广场旁）', '0', '2015-03-01 12:07:15', 'root-37-1-4', '2', '海口市区');
INSERT INTO `t_lease_address` VALUES ('f31fecc91d444f2b96904725dce50b93', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-23 18:23:02', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('f3b776d6abfc4f57b20b2308f5c72531', '501296d29a5e42b7a2e5aa1f1a13f77f', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-03 12:14:42', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('f81ee136d8704a5bac4ce5bb5c4ee749', 'f922846e30df44459b6c2a7f914ed9eb', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-02 16:37:33', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('fb271806c6e542d5a1fd6ccc90d34cbb', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-2', '三亚凤凰路南方航空商铺4—101', '0', '2015-02-23 18:23:02', 'root-37-2-1', '4', '三亚市区');
INSERT INTO `t_lease_address` VALUES ('fb609d253c0e45ddaa63f3669494545c', '265255fff60f48aba4349a28db794a8c', 'root-37', 'root-37-2', '三亚凤凰机场到达出口', '0', '2015-02-13 17:09:16', 'root-37-2-1', '3', '凤凰机场');
INSERT INTO `t_lease_address` VALUES ('fb61926aec91433a9addee3405fabde4', '1594d0bdbff942109df99d8b610265dd', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-23 18:23:02', 'root-37-1-4', '1', '美兰机场');
INSERT INTO `t_lease_address` VALUES ('fc6b126869564436b2e4ebb81be87a3c', '559aedce220247109c18afa0aad97e63', 'root-37', 'root-37-1', '海口美兰机场1楼到达厅出口左转20米', '1', '2015-02-24 08:04:45', 'root-37-1-4', '1', '美兰机场');

-- ----------------------------
-- Table structure for t_lease_holiday
-- ----------------------------
DROP TABLE IF EXISTS `t_lease_holiday`;
CREATE TABLE `t_lease_holiday` (
  `id` int(32) NOT NULL auto_increment,
  `lease_id` int(32) default NULL COMMENT '租赁商',
  `holiday` datetime default NULL COMMENT '节假日日期',
  `holiday_type` int(11) default NULL COMMENT '假日类型(普通,特殊)',
  `create_date` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `t_lease_holidy_leaseId` USING BTREE (`lease_id`),
  KEY `t_lease_holidy_holiday_type` USING BTREE (`holiday_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='租车特殊假日配置';

-- ----------------------------
-- Records of t_lease_holiday
-- ----------------------------

-- ----------------------------
-- Table structure for t_logging
-- ----------------------------
DROP TABLE IF EXISTS `t_logging`;
CREATE TABLE `t_logging` (
  `id` int(11) NOT NULL,
  `user_host` varchar(32) default NULL,
  `user_uri` varchar(32) default NULL,
  `user_method` varchar(32) default NULL,
  `create_date` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_logging
-- ----------------------------
INSERT INTO `t_logging` VALUES ('1', null, null, null, '2018-07-11 10:53:18');
INSERT INTO `t_logging` VALUES ('2', null, null, null, '2018-07-19 10:53:35');
INSERT INTO `t_logging` VALUES ('3', null, null, null, '2018-07-10 10:53:40');
INSERT INTO `t_logging` VALUES ('4', null, null, null, '2018-06-20 10:53:43');
INSERT INTO `t_logging` VALUES ('5', null, null, null, '2018-05-09 11:21:15');
INSERT INTO `t_logging` VALUES ('6', null, null, null, '2018-08-15 11:21:51');
INSERT INTO `t_logging` VALUES ('7', null, null, null, '2018-08-03 11:21:56');
INSERT INTO `t_logging` VALUES ('8', null, null, null, '2017-03-15 11:23:54');
INSERT INTO `t_logging` VALUES ('9', null, null, null, '2018-03-15 11:43:53');
INSERT INTO `t_logging` VALUES ('10', null, null, null, '2016-08-25 13:01:15');

-- ----------------------------
-- Table structure for t_member
-- ----------------------------
DROP TABLE IF EXISTS `t_member`;
CREATE TABLE `t_member` (
  `id` int(11) NOT NULL auto_increment,
  `member_name` varchar(20) default NULL COMMENT '用户名称',
  `login_name` varchar(20) default NULL COMMENT '用户登录名',
  `member_pwd` varchar(32) default NULL,
  `gender` int(11) default NULL COMMENT '用户性别',
  `nick_name` varchar(20) default NULL COMMENT '用户别名',
  `id_card` varchar(20) default NULL COMMENT '用户身份证号',
  `mobile_phone` varchar(15) default NULL COMMENT '用户手机',
  `email` varchar(20) default NULL COMMENT '用户邮箱(暂不显示)',
  `icon` varchar(200) default NULL COMMENT '用户头像(暂不显示)',
  `birth_day` date default NULL COMMENT '用户出生年月(暂不显示)',
  `province` varchar(20) default NULL COMMENT '省',
  `city` varchar(20) default NULL COMMENT '市',
  `area` varchar(20) default NULL COMMENT '区域',
  `address` varchar(200) default NULL COMMENT '地区',
  `lease_id` varchar(32) default NULL COMMENT '租赁商id',
  `member_type` int(11) default NULL COMMENT '用户类型  普通会员 或者租赁商',
  `CREATE_DATE` date default NULL,
  `member_state` int(11) default NULL,
  `push_user_id` varchar(32) default NULL COMMENT '推送ID(如tokenID等)',
  `push_channel_id` varchar(32) default NULL COMMENT '推送渠道ID',
  `mobile_type` varchar(10) default NULL COMMENT '手机类型',
  `level` varchar(32) default '1' COMMENT '»áÔ±¼¶±ð',
  `referrer_id` varchar(32) default NULL COMMENT '»áÔ±¸¸±àºÅ',
  `THIRDUSERID` varchar(64) default NULL COMMENT 'µÚÈý·½USERID',
  `THIRDTOKEN` varchar(64) default NULL COMMENT 'µÚÈý·½Token',
  `THIRDTYPE` varchar(10) default NULL COMMENT 'Éí·ÝÀàÐÍ\n\n',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `mobile_phone_thirdType` (`mobile_phone`,`THIRDTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员表';

-- ----------------------------
-- Records of t_member
-- ----------------------------
INSERT INTO `t_member` VALUES ('1', '袁军', '15087708501', 'C4CFA9FEEC9CD2D63129BC9C5C0F77BB', null, '鲁智深', '530423198810110030', '15087708501', null, null, null, null, '北京市', '朝阳区', null, null, '0', '2015-02-10', null, '0', '0', '2', '高级会员', null, null, null, '0');
INSERT INTO `t_member` VALUES ('2', '刘佳良', '18976889728', '67CF30D14598E14724A8F636C2598D34', null, '小黑', '430181198812254410', '18976889728', 'xiaohei@163.com', null, '1996-06-06', '', '上海市', null, null, null, '0', '2015-01-21', null, '606636004728871246', '3876422338743564414', '1', '普通会员', null, null, null, '0');
INSERT INTO `t_member` VALUES ('3', '程风', '13700496016', '778BB69B6EA94C0AC96024BF36B23D68', null, 'youngster', '412701199011071520', '13700496016', null, null, null, '广东省', '江门市', null, null, null, '0', '2015-01-27', null, '782801299902973331', '4251715190728822828', '1', '普通会员', null, null, null, '0');
INSERT INTO `t_member` VALUES ('4', '陈肖霖', '18092168618', 'C59D01C0DB432D6E0A3B8D08C7C4FA1E', null, '张飞', '612322198707110018', '18092168618', null, null, null, null, null, null, null, null, '0', '2015-02-04', null, '714351104392818263', '4221912581118389493', '1', '普通会员', null, null, null, '0');
INSERT INTO `t_member` VALUES ('5', 'chen', '1222', '1222', '0', null, null, '1222', null, null, null, null, null, null, null, null, '0', null, '0', null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for t_member_active
-- ----------------------------
DROP TABLE IF EXISTS `t_member_active`;
CREATE TABLE `t_member_active` (
  `id` varchar(32) NOT NULL,
  `member_id` varchar(50) default NULL COMMENT 'ÓÃ»§id',
  `active_id` varchar(50) default NULL COMMENT '»î¶¯id',
  `order_id` varchar(50) default NULL COMMENT '¶©µ¥id',
  `isused` varchar(1) default NULL COMMENT 'ÊÇ·ñÒÑÊ¹ÓÃ 1ÒÑÊ¹ÓÃ 0Î´Ê¹ÓÃ',
  `public_member` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ÓÃ»§»î¶¯±í';

-- ----------------------------
-- Records of t_member_active
-- ----------------------------
INSERT INTO `t_member_active` VALUES ('019061a6003f4ede88fbbed7313b6cee', '3afd8e9ad43943b59dc329b5c0116742', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'ab1986cd9b4142e9830d9581ed99d41d');
INSERT INTO `t_member_active` VALUES ('019d8cdbf2a54da3b29530179bb75552', 'c30803c202f5411c83c5e07c091af180', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'c30803c202f5411c83c5e07c091af180');
INSERT INTO `t_member_active` VALUES ('057b80a1c7404014a5aae20baf1895b9', 'adfd24e38f324409a40bca2e9ecf9d8d', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adfd24e38f324409a40bca2e9ecf9d8d');
INSERT INTO `t_member_active` VALUES ('0645077f44b54d62a209f164fa194c32', 'b0e3239bb2df48ad9af991863c6fbe0b', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('06e6fb6aa43c49758e29bed8dc5098c8', '7f66d020921a47ef83f05f6f4f604175', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('076aed198711437ab1faa395523a4355', '89a3879f4315430bbe4541cb72423883', 'd05b47831a7348229661c53cb638cd2c', null, '0', '59fc753bf1fa4b16af7edb63ee4a3ce2');
INSERT INTO `t_member_active` VALUES ('081f11da07ac4a94b4676264ef15f4e7', 'd525aef2905f44a3b9c5a731cd41d648', 'd05b47831a7348229661c53cb638cd2c', null, '0', '660a80746f774081850128788f80aa31');
INSERT INTO `t_member_active` VALUES ('08b38c6d3b504df8b3634656f7eedfd7', 'b3a22ed4f5ee437187298f610edddb2b', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'ab1986cd9b4142e9830d9581ed99d41d');
INSERT INTO `t_member_active` VALUES ('08b9891b64f744fd93b9580b4e99c0f7', 'd215dc7ce6f64b9a85e6342a11c566c5', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('09b0d9e2d73b4dd6b4a276d0c146eb5c', '9b812ddfe35c46408ad3a8e8edc626b6', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'bc4f2c3dde8c4e898bbedee8b53a293c');
INSERT INTO `t_member_active` VALUES ('09fc1b3add4b470dba922c7eb11ee6b4', '9404926a3f354217b520abe45d6529c5', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('0c3a72fd0eb649c2866dd133a70affd5', 'd7522b3709f04d52946c76eb17cb568f', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'd7522b3709f04d52946c76eb17cb568f');
INSERT INTO `t_member_active` VALUES ('0cda835236d6447384e65a9bb538113a', '0abeeb425cc34fd7b9dd2ebded3138c7', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('0daecf5cdd974a47807cfa8276319c0c', '0e1566ef11b441e499d42b6f7144f483', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('0e4dae2ceb09430e95d0c297b6722bc3', '0ee76310644d45aeaec6b49b927e8ead', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'b628fc89abb8473689304d16eb96fc88');
INSERT INTO `t_member_active` VALUES ('0fffb50c96ce427bbcb18fc0ba3f5f2c', '660a80746f774081850128788f80aa31', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('101e23f8bc57480682698f23696146a7', 'b1b7c6cee7394ac5bf9ad926b91a4936', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('10b8c8eae2d24a4c8b23dd9db59304c8', '5f2503947fd846cc94a0158ed25116b8', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('10d96238b70940e0a3c17f4abfc136e2', '507944bbff5f4a5cbbfc8d3644a0b024', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e29efb39870f4b7eb07c643057f5bcd8');
INSERT INTO `t_member_active` VALUES ('1119787c3b2a451d9c45575699816ecc', 'f6f41349fd714826945d21f4c3554ffe', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'f6f41349fd714826945d21f4c3554ffe');
INSERT INTO `t_member_active` VALUES ('1264804bf3bc4a02b033495974a48e54', '8fd7efaa6d73412c835ef8738eba668c', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('128f96b3150941688363ea678bcc4ae6', 'bc4f2c3dde8c4e898bbedee8b53a293c', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('1486ddaff7f24d3c9cdb8854127c147f', '391e1bfa082a457ea3a6f1ca46736c5e', 'd05b47831a7348229661c53cb638cd2c', null, '1', '59fc753bf1fa4b16af7edb63ee4a3ce2');
INSERT INTO `t_member_active` VALUES ('14a27f20398342a4a95bc030515da391', '1d885774d2c549a8bda0d6b12e7a627a', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('15728eaca24a4b3499d2cd8c3e103f6d', '06fcbe36ba0d404fb125b351fe94cb34', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'd7522b3709f04d52946c76eb17cb568f');
INSERT INTO `t_member_active` VALUES ('15d6513c34c74952b9ea86d8b1fcc10e', '85bbf43c032048f38eb37f9904ac4664', 'd05b47831a7348229661c53cb638cd2c', null, '1', '85bbf43c032048f38eb37f9904ac4664');
INSERT INTO `t_member_active` VALUES ('16f672cd195642e1b5433a54ee233a00', '0bccb77dd07947ccb1938f61d7c11735', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('17cab86dce1440008d01fc70fb6dfb3f', '3155ec3a271f4619a100b98cc2f8a282', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('18dec8ca5f024d34b4e5d66cd132408b', '07229505ed2043a5a38af7c9b9d4a039', 'd05b47831a7348229661c53cb638cd2c', null, '1', '07229505ed2043a5a38af7c9b9d4a039');
INSERT INTO `t_member_active` VALUES ('195320a52b3741b4924e2b9cc57f50f2', 'dc4f5c5d228247e5ae4c56ba734e0dde', 'd05b47831a7348229661c53cb638cd2c', null, '0', '817b4a1bb17443119b056b2f0df7ba85');
INSERT INTO `t_member_active` VALUES ('1e307b9fb5e04d72bbc89de510cdfd3b', '2f9fab6a42dd4754884bd665adb53bdf', 'd05b47831a7348229661c53cb638cd2c', null, '0', '59fc753bf1fa4b16af7edb63ee4a3ce2');
INSERT INTO `t_member_active` VALUES ('1e8a2c8e70cc43fcb7bbd799cd79f7b2', 'adbd88d2427e411b9ef2a9c0ecc88c40', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('1ecf3390261d4ead9fb850006af68b0e', '1add54bafa1a4944aacdcf23ab249a7a', 'd05b47831a7348229661c53cb638cd2c', null, '1', '31a1ebfafd6142b29501b631bdb4a651');
INSERT INTO `t_member_active` VALUES ('1f884f7cbf524f2ab04d64bc109516e6', '28568cb569f442e089e2e172a882219b', 'd05b47831a7348229661c53cb638cd2c', null, '1', '4eb0fb29c7d048f1ada2f9d1ada3ed9f');
INSERT INTO `t_member_active` VALUES ('217a62dfe6454f70a45550f0db7dd27d', 'c97f2fd134464ec3af583535308d405f', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'c97f2fd134464ec3af583535308d405f');
INSERT INTO `t_member_active` VALUES ('21cfd25841d84ee186850bf9464d4e3f', '15db52bfdd62496dbfd47598e15708cb', 'd05b47831a7348229661c53cb638cd2c', null, '1', '15db52bfdd62496dbfd47598e15708cb');
INSERT INTO `t_member_active` VALUES ('23cb752701e74f62a61d7d349c2f7950', '09389eca64244279a045d4b0a8e8d408', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('24c1cb316dee405bbda6b06b9f517ae3', 'e966138ffca2493792d675d5371b4ace', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('25534a2983a84c218388c411ad8c6f8f', '96c784c709404ba2ac03cf2d54cc5dd4', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'bc4f2c3dde8c4e898bbedee8b53a293c');
INSERT INTO `t_member_active` VALUES ('25d1fb94d9034efbb63e4d8c8f91e855', 'c43836d6a2244526a352f26f2c9212f5', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('283fa73bc05141c59243c9f32640150e', '6b1835fce9aa4a22ab8f786ef0cecf3c', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('2a23ba288bf44da68607863e567bea85', 'ce9ebe0b70a94249a3b2df8235017ebe', 'd05b47831a7348229661c53cb638cd2c', null, '0', '28568cb569f442e089e2e172a882219b');
INSERT INTO `t_member_active` VALUES ('2b1b623716b245adaba255ca69568096', '44402951207c4d7eb4f2e06929860ad5', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('2db413fec6ab4feb9166a6749074f2d4', '92220ad288474c5980a95592bb68e806', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('2ee2abff86fe4c6893af54f2956ff076', 'dd07b88c38ac4abcb9ad8e67415354ab', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('320ded1f6fd44d52aed35b1e67c11dac', 'ab1986cd9b4142e9830d9581ed99d41d', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'ab1986cd9b4142e9830d9581ed99d41d');
INSERT INTO `t_member_active` VALUES ('3455daac8a284cf5bafefa919d2cc1f2', '5f2c32aecc534ba2a9bcf8e7570bef6b', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'c71930a2661f49c0a4e3f4b68c91344f');
INSERT INTO `t_member_active` VALUES ('38f3203e9c3b43be98472d667f6d0669', 'a01931669b72475cb0a1c05b06cf3a25', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('397672700e57424e9d5fe22d49127e1d', 'bf381853f798490f8aba8500de17b49a', 'd05b47831a7348229661c53cb638cd2c', null, '0', '59fc753bf1fa4b16af7edb63ee4a3ce2');
INSERT INTO `t_member_active` VALUES ('39bc98a8371245ff8269eb843c6594b7', '74ef7ecc29b247678a542f2c5f82e41a', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'bc4f2c3dde8c4e898bbedee8b53a293c');
INSERT INTO `t_member_active` VALUES ('3a4f97e2e81a4980a1ee83060adaba87', '4eb0fb29c7d048f1ada2f9d1ada3ed9f', 'd05b47831a7348229661c53cb638cd2c', null, '1', '07229505ed2043a5a38af7c9b9d4a039');
INSERT INTO `t_member_active` VALUES ('3af316b0a3214cd2af894083d80fe78f', '902c306651f249aa91f0ffd1f55584c4', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('3b22be0fcf09458ea1649693de660ef6', '64c1dc0377b342958947f05d1b28c8e2', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('3ba967e015364bc4911c2e9fdeb98f7b', '55094b289a1340d3b61723315406e38d', 'd05b47831a7348229661c53cb638cd2c', null, '1', '55094b289a1340d3b61723315406e38d');
INSERT INTO `t_member_active` VALUES ('3c3ee9eadbb54bd79ae04e7d0464b7ae', 'bd3f95ec8e664bfb9c0ed8037930e981', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('3cfaec4bef424fbd9d8b52da47d358b6', 'c421c3e94c9b41f593c633b4fa7f42d1', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'c421c3e94c9b41f593c633b4fa7f42d1');
INSERT INTO `t_member_active` VALUES ('3ea1b818279d4aebbf02b5a15e852ada', '44fcbe931fef4aefb5e3aff821546d05', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('3fc03760aa7e4dc4815a7c8ca6b74427', '54c3970712064dd98788c0c484f829f6', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('4015e3f71664453f93200c2aae2ff3c2', '013e44dfc9a64352a8e00d55d9694e38', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('426e258452134067bb29cf8cfdef6e92', '470662ed1dcb432da0911ccff3696b9e', 'd05b47831a7348229661c53cb638cd2c', null, '0', '4b632216cada42bbb03f5006ee48a42f');
INSERT INTO `t_member_active` VALUES ('44d3166e491245139dfc11e5642c99a6', 'fba1a4a7bf2f4a0780c45ac9e8f1344f', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'bc4f2c3dde8c4e898bbedee8b53a293c');
INSERT INTO `t_member_active` VALUES ('454bfb6f402e45e0b822d4ecc4c93a85', '7343681ba3ca4230a5db3898ad8a1738', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('46cda40e6f664cc8a29c64060958e501', 'd712b2fc402641869a3ad72da8c84919', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('4acb66bbf5af453c81d17a20a6e645f4', '1afc50337a9f4a8480afe6f50b11e1f1', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('4b9cc3e60a60430e896b3cbe4345bc21', '5c69003bcca64a02bb8eedbd6f1abe85', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'b628fc89abb8473689304d16eb96fc88');
INSERT INTO `t_member_active` VALUES ('4ba9a2104aa34640a2490d61b35af5ca', 'e532d583bab741a2be656e5604177358', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('4c1f3e1924c2440699835cac237295eb', 'f1ab0b60f80b4bbf9768e512a42b17c5', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('4e463534c6e7453f99b94f8e8c3fae7e', 'd3d5d03ef95a4b44a39962564160adb2', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('4f0810126f5143db8e1962a9fc060c8d', 'e0c50ea7c79044c39cf13b61eb364784', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('508dac38da91498990816545bf4b12cc', 'b628fc89abb8473689304d16eb96fc88', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('512c4408f0664812ab67e99b7f3ba57a', 'da5bdb74d70c446893cd60c780d0df8e', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('525646683b264d00bd8c9d6ccb54256e', '90adacf277fa4f6780bedc11d329e0dd', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('58c84384017d45f284d001b9c212249b', 'a4535d911f554ea889fd1cde130a53eb', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('5a19b27993334661af7fd16e83df3d43', '36e5524c8eb4444088138829176ad33d', 'd05b47831a7348229661c53cb638cd2c', null, '0', '31a1ebfafd6142b29501b631bdb4a651');
INSERT INTO `t_member_active` VALUES ('5a4de82c4d4a4bb6a195f3ca37e80db1', 'aae9a83c16e843bf97226430e9cc9288', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('5a9caba5d0934045abcd04594746558a', '321bde1228cd4ed2ae1b56408c31b4b7', 'd05b47831a7348229661c53cb638cd2c', null, '1', '321bde1228cd4ed2ae1b56408c31b4b7');
INSERT INTO `t_member_active` VALUES ('5b49707c1aa247e5a7fe6e4e03660202', '042f4af14e3541b39580e95df5a41d61', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('5b61618f96864f04bbf49eeba658e762', '3bea002a05994ca39b4efaa4dfbdbb2e', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('5ce532dd57f047ec8520d5003586d7b6', 'cdb75f2e65e44beaa7a3988475a2855f', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('5ec6ea932a2f4df9bbac96fd3b26628e', '4523c43c02a8430e994ab39de336979d', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('5fb06a4800fc49eeb187ecb011f8bfb5', '77a45eec941e46d6919884873631dc07', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'd7522b3709f04d52946c76eb17cb568f');
INSERT INTO `t_member_active` VALUES ('64e6cbfa0e284b9bb3e224d257d4017f', '6aa9c4b4d1fc43f290feafc042a2fb3e', 'd05b47831a7348229661c53cb638cd2c', null, '0', '817b4a1bb17443119b056b2f0df7ba85');
INSERT INTO `t_member_active` VALUES ('65186a6648ac47ee864b4258569b257b', 'fc76051b69784d768d5c2f742a61cc55', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('65238dcfc30041a88e1ae3a7e895d0f0', 'b72765b0141f413a98322cc99bd5d9a8', 'd05b47831a7348229661c53cb638cd2c', null, '0', '8fd7efaa6d73412c835ef8738eba668c');
INSERT INTO `t_member_active` VALUES ('6730a6bdc6744a28a040ef6f5842bff4', 'a68cadd989a04d5a939dc555de550e07', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'a68cadd989a04d5a939dc555de550e07');
INSERT INTO `t_member_active` VALUES ('680af9be48fc49a492da5656493f4555', '0b34c4bbfaea4faf94672c9efed7db71', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('6dd536eef4134213b2e5d4e36538a51c', '76eb5a9debbb45a994b2c879897594ad', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('6e38e89f4fed445f92ee7a4176fc6c83', '826ffed8496c40ebad94779cc5efafcb', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('6f52c8a36aa549d780a5bc0160adbe4b', 'd2106df214bd4c1fbc5f323535556d0a', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('6fd848470b18450c8457acf24d3c68b3', '39f9e4eeaa1649a2a28f7192843c3186', 'd05b47831a7348229661c53cb638cd2c', null, '1', '07229505ed2043a5a38af7c9b9d4a039');
INSERT INTO `t_member_active` VALUES ('6fde98e9fa374e73adf7a125e956efd7', '91758cd502604b40900c8bd9f5ebe81b', 'd05b47831a7348229661c53cb638cd2c', null, '0', null);
INSERT INTO `t_member_active` VALUES ('710f2043442e4cdd84fa40fcfa8c844e', '037283504a2342febbdf199c8a6a807e', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('713895aa56e141808459e01deb468b69', '4893ea80ae4b4311b26bb9e9ccd7dc2d', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('71603d130c58434ab4798c3399518adc', '123523be731b43b7a9aa8d961975f873', 'd05b47831a7348229661c53cb638cd2c', null, '0', '59fc753bf1fa4b16af7edb63ee4a3ce2');
INSERT INTO `t_member_active` VALUES ('74780203af3d421581b01ad641423337', '2b08cab0638d4605929a78d074d376ed', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('7488a6e00d574e4c84604528477bfbf8', '90931df136854de7adfce0da3889898c', 'd05b47831a7348229661c53cb638cd2c', null, '1', '4eb0fb29c7d048f1ada2f9d1ada3ed9f');
INSERT INTO `t_member_active` VALUES ('764f61e0b5d341b8990496d8585b6336', '2497aa79ad65431393df0525234f1f30', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('784e6a6407c44424b53a53f837225509', '53a92bcf8e30428bb5fe6579e1a729b8', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('79ab4b6c41284ef19d018776f701642d', 'e3b814606ffa4a358624f861f401b134', 'd05b47831a7348229661c53cb638cd2c', null, '1', '9a09f0cab1494c1d976e9c4593bd6203');
INSERT INTO `t_member_active` VALUES ('7c860b3796b34b60a34e6bc03b2b6ce1', '72cb61161aab49f781a479f8a9c7cd65', 'd05b47831a7348229661c53cb638cd2c', null, '1', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('7cff222d529044da8118aedb58c63c99', 'ffb0c1916c7140fcbc05f343c4a7209f', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'adbd88d2427e411b9ef2a9c0ecc88c40');
INSERT INTO `t_member_active` VALUES ('7d8011cac29c41de87e6fb24a3dbc40b', 'c3348d5379984e03ae6716f61064a84e', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'e966138ffca2493792d675d5371b4ace');
INSERT INTO `t_member_active` VALUES ('7dd1601889044b6394264e85b3ae1c7a', 'c98fff00a8704a2da60b209595fb493d', 'd05b47831a7348229661c53cb638cd2c', null, '0', 'bc4f2c3dde8c4e898bbedee8b53a293c');
INSERT INTO `t_member_active` VALUES ('7e1e778780d04c3691859e810a084a19', '00bb638c6e3649e28f633d6242db74b5', 'd05b47831a7348229661c53cb638cd2c', null, '1', '4eb0fb29c7d048f1ada2f9d1ada3ed9f');
INSERT INTO `t_member_active` VALUES ('811063fefd5f4dbdbaa3b82801e4decc', '6ab1fc68cf6749debca9ff66349467e0', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);
INSERT INTO `t_member_active` VALUES ('811f7ee88df642fab608184f56953402', 'a09d7abe5e0c4fe0b5aa71f115cdf473', 'd05b47831a7348229661c53cb638cd2c', null, '1', null);

-- ----------------------------
-- Table structure for t_order
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` int(11) NOT NULL,
  `order_no` varchar(32) default NULL COMMENT '订单编号',
  `member_id` int(11) default NULL COMMENT '会员id',
  `lease_id` int(11) default NULL COMMENT '租赁商id',
  `rental_fee` double(20,2) default NULL COMMENT '租车费',
  `insurance_fee` double(20,2) default NULL COMMENT '保险费',
  `deposit_fee` double(20,2) default NULL COMMENT '订单车辆押金',
  `illegal_fee` double(20,2) default NULL COMMENT '订单违章押金',
  `coupons_fee` double(20,2) default NULL COMMENT '代金券抵用金额',
  `factorage_fee` double(20,2) default NULL COMMENT '订单手续费',
  `emptDrive_fee` double(20,2) default NULL COMMENT '车辆空驶费',
  `activity_fee` double(20,2) default NULL COMMENT '车辆活动优惠费',
  `pay_fee` double(20,2) default NULL COMMENT '订单应付金额',
  `pay_type` int(11) default NULL COMMENT '付款方式',
  `pay_company` int(11) default NULL COMMENT '支付平台',
  `pay_time` datetime default NULL COMMENT '支付时间',
  `base_state` int(11) default NULL COMMENT '订单基本状态',
  `pay_state` int(11) default NULL COMMENT '订单支付状态',
  `take_state` int(11) default '0',
  `create_time` datetime default NULL COMMENT '订单生成时间',
  `delete_state` int(11) default NULL COMMENT '删除状态',
  `member_message` varchar(200) default NULL COMMENT '买家留言',
  `member_nick` varchar(20) default NULL COMMENT '买家昵称',
  `canceled_message` varchar(200) default NULL COMMENT '订单取消原因',
  `canceled_time` datetime default NULL COMMENT '取消时间',
  `isrelet` int(11) default NULL COMMENT '是否续租0否,1是',
  `reletOrder` varchar(32) default NULL COMMENT '续租单号(原订单要填写)',
  `sourcOrder` varchar(32) default NULL COMMENT '原单号(续租单要填写)',
  `need_invoice` int(11) default '0' COMMENT '是否需要发票0:不需要 1:需要',
  `overtime_charge` double(10,2) default '0.00' COMMENT '¶©µ¥³¬Ê±»¹³µ·Ñ',
  `handler` varchar(32) default NULL,
  `refuse_time` datetime default NULL,
  `receipt` varchar(100) default NULL COMMENT 'å‘ç¥¨æŠ¬å¤´',
  `reason` varchar(100) default NULL COMMENT 'ç»“ç®—å·®é¢è¯´æ˜Ž',
  `PLATE_NUMBER` varchar(32) default NULL COMMENT 'è½¦ç‰Œå·',
  `VOUCHER_FEE` double(20,2) default '0.00' COMMENT 'µç×ÓÇ®°üÏû·Ñ½ð¶î',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `order_no` (`order_no`),
  UNIQUE KEY `order_no_2` (`order_no`),
  UNIQUE KEY `order_no_3` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1', '2', '4', '5', '600.00', '90.00', '3000.00', '2000.00', '100.00', '0.00', null, null, '590.00', '0', null, null, '4', '1', '2', '2015-02-13 16:19:52', '0', null, '13717026100', null, null, null, null, null, '0', '0.00', null, null, null, null, null, null);
INSERT INTO `t_order` VALUES ('2', '3', '3', '3', '780.00', '90.00', '3000.00', '2000.00', '0.00', '0.00', '300.00', null, '1170.00', '0', null, null, '4', '0', '0', '2015-01-24 14:30:07', '0', null, '13717026100', null, '2015-01-24 14:32:27', null, null, null, '0', '0.00', '0cee4edf71d24a16ac2f559e7dd0a946', '2015-01-24 14:31:49', null, null, null, '0.00');
INSERT INTO `t_order` VALUES ('3', '4', '2', '4', '1610.00', '210.00', '3000.00', '2000.00', '100.00', '0.00', null, null, '1720.00', '0', null, null, '4', '1', '0', '2015-02-06 15:55:04', '0', null, '13942665088', null, '2015-02-06 16:02:27', null, null, null, '0', '0.00', null, null, null, null, null, '0.00');

-- ----------------------------
-- Table structure for t_order_car
-- ----------------------------
DROP TABLE IF EXISTS `t_order_car`;
CREATE TABLE `t_order_car` (
  `id` int(11) NOT NULL,
  `member_id` int(11) default NULL COMMENT '会员id',
  `lease_id` int(11) default NULL COMMENT '租赁商id',
  `lease_Name` varchar(32) default NULL COMMENT '租赁商名称',
  `order_no` varchar(32) default NULL COMMENT '订单编号',
  `car_id` int(11) default NULL COMMENT '车辆id',
  `car_name` varchar(100) default NULL COMMENT '车辆名称',
  `car_no` varchar(32) default NULL COMMENT '车辆编号',
  `car_type` varchar(20) default NULL COMMENT '车辆类型',
  `car_type_name` varchar(50) default NULL COMMENT '车辆类型名称',
  `car_brand` varchar(32) default NULL COMMENT '车辆品牌',
  `car_brand_name` varchar(50) default NULL COMMENT '车辆品牌名称',
  `car_serial` varchar(20) default NULL COMMENT '车系编号',
  `car_serial_name` varchar(50) default NULL COMMENT '车系编号名称',
  `gear` varchar(20) default NULL COMMENT '排档',
  `gear_name` varchar(20) default NULL COMMENT '排档名称',
  `displacement` varchar(10) default NULL COMMENT '排量',
  `seating` int(11) default NULL COMMENT '座位数',
  `plate_DOUBLE` varchar(10) default NULL COMMENT '车辆车牌(扩展用,暂不用)',
  `car_pic` varchar(200) default NULL COMMENT '车辆图片',
  `order_start_time` datetime default NULL COMMENT '订车开始时间',
  `order_end_time` datetime default NULL COMMENT '订车结束时间',
  `tack_address_id` varchar(32) default NULL COMMENT '取车地点编号',
  `tack_address` varchar(200) default NULL COMMENT '取车地点',
  `return_address_id` varchar(32) default NULL COMMENT '还车地点编号',
  `return_address` varchar(200) default NULL COMMENT '还车地点',
  `normal_price` double(20,2) default NULL COMMENT '车辆价格普通价',
  `holiday_price` double(20,2) default NULL COMMENT '车辆假日价',
  `special_price` double(20,2) default NULL COMMENT '车辆特殊价',
  `feeDetail` varchar(1000) default NULL,
  PRIMARY KEY  (`id`),
  KEY `t_order_car_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单车辆信息';

-- ----------------------------
-- Records of t_order_car
-- ----------------------------
INSERT INTO `t_order_car` VALUES ('1', '4', '3', '思福行政车队', '2', '2', '丰田 考斯特豪华', '99291d4911c14e89a41525c395b880e0', 'zhongba', '中巴', 'toyota', '丰田', 'toyota-costahaohua', '考斯特豪华', 'ZD', '自动', '3.5 ', '13', null, 'toyota-kesida.jpg', '2015-01-09 07:40:11', '2015-03-05 21:40:27', '2', '海口市区', '2', '海口市区', '1500.00', '1500.00', '1500.00', '2015-01-09至2015-03-05#84000.0');
INSERT INTO `t_order_car` VALUES ('2', '3', '3', '思福行政车队', '3', '2', '丰田 考斯特豪华', '99291d4911c14e89a41525c395b880e0', 'zhongba', '中巴', 'toyota', '丰田', 'toyota-costahaohua', '考斯特豪华', 'ZD', '自动', '3.5 ', '13', '', 'toyota-kesida.jpg', '2015-01-09 07:40:11', '2015-03-05 21:40:27', '2', '海口市区', '2', '海口市区', '1500.00', '1500.00', '1500.00', '2015-01-09至2015-03-05#84000.0');
INSERT INTO `t_order_car` VALUES ('3', '2', '3', '思福行政车队', '4', '2', '丰田 考斯特豪华', '99291d4911c14e89a41525c395b880e0', 'zhongba', '中巴', 'toyota', '丰田', 'toyota-costahaohua', '考斯特豪华', 'ZD', '自动', '3.5 ', '13', null, 'toyota-kesida.jpg', '2015-01-09 07:40:11', '2015-03-05 21:40:27', '2', '海口市区', '2', '海口市区', '1500.00', '1500.00', '1500.00', '2015-01-09至2015-03-05#84000.0');

-- ----------------------------
-- Table structure for t_order_take_car
-- ----------------------------
DROP TABLE IF EXISTS `t_order_take_car`;
CREATE TABLE `t_order_take_car` (
  `id` int(11) NOT NULL,
  `order_no` varchar(11) default NULL COMMENT '订单编号',
  `user_real_name` varchar(20) default NULL COMMENT '取车人真实姓名',
  `user_idcard` varchar(20) default NULL COMMENT '取车人身份证号',
  `user_phone` varchar(15) default NULL COMMENT '取车人手机号',
  `take_date` datetime default NULL COMMENT '取车时间',
  `return_date` datetime default NULL COMMENT '还车时间',
  PRIMARY KEY  (`id`),
  KEY `t_order_take_car_order_no` (`order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单取车信息';

-- ----------------------------
-- Records of t_order_take_car
-- ----------------------------
INSERT INTO `t_order_take_car` VALUES ('1', '2', '何孟儒', '22030219*****60421', '18689771533', '2015-02-10 12:30:00', '2015-02-15 11:35:00');
INSERT INTO `t_order_take_car` VALUES ('2', '3', '马飞', '22030219*****60421', '18689771533', '2015-02-10 12:30:00', '2015-02-15 11:35:00');
INSERT INTO `t_order_take_car` VALUES ('3', '4', '芦苇', '22030219*****60421', '18689771533', '2015-02-10 12:30:00', '2015-02-15 11:35:00');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `username` varchar(20) default NULL,
  `useremail` varchar(20) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('aaa', 'aaa');
INSERT INTO `users` VALUES ('aaa', 'aaa');
