package com.hy.mapper;

import java.util.List;

import com.hy.model.Car;

public interface CarMapper {
	public void addCar(Car car);

	public void deleteCar(int id);

	public void updateCar(Car car);

	public List<Car> checkCarById(int id);

	public List<Car> checkAllCar();

	public List<Car> searchCar(String keyword);
}
