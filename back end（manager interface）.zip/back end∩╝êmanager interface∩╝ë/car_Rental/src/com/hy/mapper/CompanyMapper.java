package com.hy.mapper;

import java.util.List;

import com.hy.model.Company;


public interface CompanyMapper {
	
	public void addCompany(Company company);
	
	public List<Company> findCompanyById(String id);
	
	public Company findCompanyId(int id);
	
	public void updateCompanyById(Company company);
	
	public void deleteCompanyById(int id);
	
	public List<Company> findAllCompany();
}