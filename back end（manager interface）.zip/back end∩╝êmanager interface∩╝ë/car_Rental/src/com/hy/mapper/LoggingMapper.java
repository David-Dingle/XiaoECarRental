package com.hy.mapper;

import java.util.List;

import com.hy.model.Logging;
import com.hy.model.LoggingCounts;


public interface LoggingMapper {
	public void insertLogging(Logging log);
	public List<LoggingCounts> selectfromLogging();
}
