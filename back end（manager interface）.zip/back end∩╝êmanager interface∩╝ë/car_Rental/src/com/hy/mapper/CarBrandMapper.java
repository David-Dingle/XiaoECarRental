package com.hy.mapper;

import java.util.List;

import com.hy.model.CarBrand;

public interface CarBrandMapper {
	
	public void addCarBrand(CarBrand cb);
	
	public void deleteCarBrand(int id);
	
	public void updateCarBrand(CarBrand cb);
	
	public List<CarBrand> checkCarBrandById(int id);
	
	public List<CarBrand> checkAllCarBrand();
	
	public List<CarBrand> searchCarBrand(String keyword);
	
}
