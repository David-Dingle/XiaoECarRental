package com.hy.controller;

import java.io.File;
import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.editor.DateEditor;
import com.hy.model.Company;
import com.hy.model.Member;

import com.hy.service.MemberService;

@Controller
@RequestMapping("/Member")
public class MemberController {
	@Autowired
	private MemberService ms;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(Date.class,"birth_day",new DateEditor());
	}
	
	@RequestMapping("/add")
	public String addMember(Member member, @RequestParam("file") MultipartFile file, HttpServletRequest req) {
		String fileName = Math.random() + file.getOriginalFilename();
		String path = req.getServletContext().getRealPath("/upload/member");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ����ͼƬ��ַ
		member.setIcon("upload/member/" + fileName);
		ms.addMember(member);
		return "redirect:/Member/checkAll.do";
	}
	
	@RequestMapping("/checkAll")
	public String checkMember(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn) {
		PageHelper.startPage(pn, 6);
		List<Member> members = ms.checkAllMember();
		PageInfo<Member> pageInfo = new PageInfo<>(members,5);
		model.addAttribute("allmembers", pageInfo);
		return "forward:/member_list.jsp";
	}
	
	@RequestMapping("/update")
	public String updateMember(Member member,@RequestParam("file") MultipartFile file, HttpServletRequest req) {
		
		String fileName = Math.random() + file.getOriginalFilename();
		String path = req.getServletContext().getRealPath("/upload/member");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ����ͼƬ��ַ
		member.setIcon("upload/member/" + fileName);
		ms.updateMember(member);
		return "redirect:/Member/checkAll.do";
	}
	/*
	 * �����޸�ҳ��
	 */
	@RequestMapping("/selectone/{id}")
	public String selectMember(@PathVariable int id, Model model) {
		List<Member> members = ms.checkMemberById(id);
		model.addAttribute("member", members);
		return "forward:/member_update.jsp";
	}
	/*
	 * ��ѯ��ϸ��Ϣ
	 */
	@RequestMapping("/checkone/{id}")
	public String checkMember(@PathVariable int id, Model model) {
		List<Member> member = ms.checkMemberById(id);
		model.addAttribute("member", member);
		return "forward:/member_checkResult.jsp";
	}
	/*
	 * ����
	 */
	@RequestMapping("/search")
	public String searchMember(String level,String keyword, Model model) {
		List<Member> members = ms.searchMember(keyword,level);
		model.addAttribute("allmembers", members);
		return "forward:/member_searchResult.jsp";
	}
	/*
	 * ɾ��
	 */
	@RequestMapping("/delete/{id}")
	public String addMember(@PathVariable int id) {
		ms.deleteMember(id);
		return "redirect:/Member/checkAll.do";
	}
}
