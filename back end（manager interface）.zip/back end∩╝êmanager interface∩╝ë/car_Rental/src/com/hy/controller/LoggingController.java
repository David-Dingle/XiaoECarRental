package com.hy.controller;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hy.model.Logging;
import com.hy.model.LoggingCounts;
import com.hy.service.ILoggingservice;

@Controller
@RequestMapping("/logging")
public class LoggingController {

	@Autowired
	public ILoggingservice ilogging;
	@RequestMapping("/add")
	public String addrLogging(HttpServletRequest request)
	{
		Logging log = new Logging();		
		log.setCreate_date(new Timestamp(System.currentTimeMillis()));
		log.setUser_method(request.getMethod());
		log.setUser_host(request.getRemoteHost());
		log.setUser_ip(request.getRemoteAddr());
		log.setUser_uri(request.getRequestURI());
		System.out.println(log);
		ilogging.insertLogging(log);
		System.out.println(log+ "==============");
		return "success";
	}
	
	@RequestMapping("/select")
	public String findLogging(HttpServletRequest request)
	{   
		List<LoggingCounts> list = ilogging.selectfromLogging();
		Iterator<LoggingCounts> it = list.iterator();
		LoggingCounts log = null;
		while(it.hasNext()){
			log = it.next();
		request.getSession().setAttribute(log.getMonths(),log.getPeoples());
		System.out.println(log.getMonths() + ":" + log.getPeoples());
		}
		return "forward:/discharge_statistic.jsp";
	}
}
