package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.Company;
import com.hy.model.Holiday;
import com.hy.service.IHolidayService;

	/**
	 * ǰ�˿�������--ʵ�ּ�����Ϣ����
	 * @author Administrator
	 *
	 */
	@Controller
	@RequestMapping("/holiday")
public class HolidayController {

		@Autowired
		private IHolidayService holidayService;
		
		@RequestMapping("/add")
		public String addholiday(Holiday holiday){
			holidayService.addHoliday(holiday);
			return "redirect:/holiday/findall.do";
		}
		/*@RequestMapping("/updateUser/{id}")
		public String updateUser(@PathVariable int id){
			return null;
		}*/
		
		/**
		 * ��ѯ����
		 * @param model
		 * @return
		 */
		@RequestMapping("/findall")
		public String findAll(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn){
			PageHelper.startPage(pn, 6);
			List<Holiday> holidays = holidayService.findAll();
			PageInfo<Holiday> pageInfo = new PageInfo<>(holidays,5);
			model.addAttribute("holidays", pageInfo);
			return "forward:/rent_car_festival_list.jsp";
		}
		
		/**
		 * ����id�������ҳ��
		 * @return
		 */
		@RequestMapping("/updateInput/{id}")
		public String updateInput(@PathVariable int id,Model model) {
			Holiday holiday = holidayService.findHolidayById(id);
			model.addAttribute("hholiday",holiday);
			return "forward:/updateHoliday.jsp";
		}
		/**
		 * ����id�������ҳ��
		 * @return
		 */
		@RequestMapping("/updateOutput")
		public String updateOutput(Holiday holiday) {
			holidayService.updateHoliday(holiday);
			return "redirect:/holiday/findall.do";
		}
		@RequestMapping("/delete/{id}")
		public String deleteHolidayById(@PathVariable int id) {
			holidayService.deleteHolidayById(id);
			return "redirect:/holiday/findall.do";
		}
		@RequestMapping("/intoadd")
		public String findallConame(Model model) {
			List<Company> companys=holidayService.findallConame();
			model.addAttribute("companys", companys);
			return "forward:/rent_car_festival_add.jsp";
		}
}
