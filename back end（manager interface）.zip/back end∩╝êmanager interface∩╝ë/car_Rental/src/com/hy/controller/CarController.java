package com.hy.controller;

import java.io.File;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.Car;
import com.hy.model.Car_type;
import com.hy.service.CarService;

@Controller
@RequestMapping("/Car")
public class CarController {

	@Autowired
	private CarService cs;
	
	@RequestMapping("/add")
	public String addCar(Car car, @RequestParam("file") MultipartFile file, HttpServletRequest req) {
		
		String fileName = Math.random() + file.getOriginalFilename();
		
		String path = req.getServletContext().getRealPath("/upload/car");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		car.setCar_pic("upload/car/" + fileName);
		//date����
		car.setCreate_date(new Date());
		cs.addCar(car);
		return "redirect:/Car/checkAll.do";
	}
	
	@RequestMapping("/checkAll")
	public String checkAllCar(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn) {
		PageHelper.startPage(pn, 6);
		List<Car> cars = cs.checkAllCar();
		PageInfo<Car> pageInfo = new PageInfo<>(cars,5);
		model.addAttribute("allcars", pageInfo);
		return "forward:/car_list.jsp";
	}
	
	@RequestMapping("/update")
	public String updateCar(Car car,@RequestParam("file") MultipartFile file, HttpServletRequest req) {
		// �ϴ�ͼƬ�ļ�
		// ��ȡ�ϴ��ļ���
		String fileName = Math.random() + file.getOriginalFilename();
		// ��ȡ�����ļ�·��
		String path = req.getServletContext().getRealPath("/upload/car");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ����ͼƬ��ַ
		car.setCar_pic("upload/car/" + fileName);
		cs.updateCar(car);
		return "redirect:/Car/checkAll.do";
	}
	
	@RequestMapping("/selectone/{id}")
	public String selectCar(@PathVariable int id, Model model) {
		List<Car> cars = cs.checkCarById(id);
		model.addAttribute("car", cars);
		return "forward:/car_update.jsp";
	}
	
	@RequestMapping("/checkone/{id}")
	public String checkCar(@PathVariable int id, Model model) {
		List<Car> cars = cs.checkCarById(id);
		model.addAttribute("allcars", cars);
		return "forward:/car_searchResult.jsp";
	}
	
	@RequestMapping("/search")
	public String searchCar(String keyword, Model model) {
		List<Car> cars = cs.searchCar(keyword);
		model.addAttribute("allcars", cars);
		return "forward:/car_searchResult.jsp";
	}
	
	@RequestMapping("/delete/{id}")
	public String addCar(@PathVariable int id) {
		cs.deleteCar(id);
		return "redirect:/Car/checkAll.do";
	}
}
