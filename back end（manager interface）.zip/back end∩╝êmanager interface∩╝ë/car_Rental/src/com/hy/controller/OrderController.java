package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.Car_type;
import com.hy.model.Company;
import com.hy.model.Order;
import com.hy.model.Order_car;
import com.hy.service.IOrderService;
import com.hy.service.ITypeService;
@Controller
@RequestMapping("/order")
public class OrderController {
		@Autowired
		private IOrderService orderService;
		
		@RequestMapping("/findall")
		public String findAll(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn){
			PageHelper.startPage(pn, 6);
			List<Order> orders =orderService.findAllOrder();
			PageInfo<Order> pageInfo = new PageInfo<>(orders,5);
			int pay_state = 2;
			model.addAttribute("orders", pageInfo);
			model.addAttribute("pay_state", pay_state);
			return "forward:/order_list.jsp";
		}
		@RequestMapping("/findbyid/{id}")
		public String find(@PathVariable int id,Model model) {
			List<Order_car> order_car = orderService.findOrder(id);
			model.addAttribute("order_car",order_car);
			return "forward:/order_detail.jsp";
			}
		@RequestMapping("/delete/{id}")
		public String deleteOrderById(@PathVariable int id) {
			orderService.deleteOrderById(id);
			return "redirect:/order/findall.do";
		}
		@RequestMapping("/search")
		public String searchMember(int pay_state,String inputvalue,Model model) {
			List<Order> orders = orderService.searchMember(pay_state,inputvalue);
			model.addAttribute("orders", orders);
			model.addAttribute("pay_state",pay_state);
			return "forward:/order_list_search.jsp";
		}
		@RequestMapping("/upPay_state/{id}")
		public String upPay_stateById(@PathVariable int id) {
			orderService.upPay_stateById(id);
			String test = "forward:/order/findbyid/"+id+".do";
			return test;
		}
		@RequestMapping("/uptake_state/{id}")
		public String upTake_stateById(@PathVariable int id) {
			orderService.upTake_stateById(id);
			String test = "forward:/order/findbyid/"+id+".do";
			return test;
		}
}
