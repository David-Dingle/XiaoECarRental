package com.hy.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.CarBrand;
import com.hy.service.CarBrandService;

/**
 * ǰ�˿�����
 */
@Controller
@RequestMapping("/CarBrand")
public class CarBrandController {
	@Autowired
	private CarBrandService cbs;

	@RequestMapping("/add")
	public String addCarBrand(CarBrand cb, @RequestParam("file") MultipartFile file, HttpServletRequest req) {
		// �ϴ�ͼƬ�ļ�
		// ��ȡ�ϴ��ļ���
		String fileName = Math.random() + file.getOriginalFilename();
		// ��ȡ�����ļ�·��
		String path = req.getServletContext().getRealPath("/upload/brand");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		cb.setPicture("upload/brand/" + fileName);
		cbs.addCarBrand(cb);
		return "redirect:/CarBrand/checkAll.do";
	}

	@RequestMapping("/checkAll")
	public String checkAllCarBrand(Model model, @RequestParam(required=false,defaultValue="1",value="pn")int pn) {
		PageHelper.startPage(pn, 6);
		List<CarBrand> brands = cbs.checkAllCarBrand();
		PageInfo<CarBrand> pageInfo = new PageInfo<>(brands,5);
		model.addAttribute("allbrands", pageInfo);
		return "forward:/car_brand_list.jsp";
	}

	@RequestMapping("/update")
	public String updateCarBrand(CarBrand cb, @RequestParam("file") MultipartFile file, HttpServletRequest req) {
		// �ϴ�ͼƬ�ļ�
		// ��ȡ�ϴ��ļ���
		String fileName = Math.random() + file.getOriginalFilename();
		// ��ȡ�����ļ�·��
		String path = req.getServletContext().getRealPath("/upload/brand");
		try {
			file.transferTo(new File(path + File.separator + fileName));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// ����ͼƬ��ַ
		cb.setPicture("upload/brand/" + fileName);
		cbs.updateCarBrand(cb);

		return "redirect:/CarBrand/checkAll.do";
	}

	@RequestMapping("/selectone/{id}")
	public String selectCarBrand(@PathVariable int id, Model model) {
		List<CarBrand> brands = cbs.checkCarBrandById(id);
		model.addAttribute("brand", brands);
		return "forward:/car_brand_update.jsp";
	}

	@RequestMapping("/search")
	public String searchCarBrand(String keyword, Model model) {
		List<CarBrand> brands = cbs.searchCarBrand(keyword);
		model.addAttribute("allbrands", brands);
		return "forward:/car_brand_searchResult.jsp";
	}

	@RequestMapping("/delete/{id}")
	public String addCarBrand(@PathVariable int id) {
		cbs.deleteCarBrand(id);
		return "redirect:/CarBrand/checkAll.do";
	}
}
