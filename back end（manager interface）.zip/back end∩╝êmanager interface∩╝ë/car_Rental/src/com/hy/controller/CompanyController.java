package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.CarBrand;
import com.hy.model.Company;
import com.hy.service.ICompanyService;

/**
 * 
 * @author david
 *
 */
@Controller
@RequestMapping("/companny")
public class CompanyController {
	@Autowired
	private ICompanyService companyService;
	
	@RequestMapping("/add")
	public String addCompany(Company company){
		companyService.addCompany(company);
		return "redirect:/companny/findall.do";
	}
	
	@RequestMapping("/findall")
	public String findAll(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn){
		PageHelper.startPage(pn, 6);
		List<Company> companys = companyService.findAll();
		PageInfo<Company> pageInfo = new PageInfo<>(companys,5);
		model.addAttribute("company", pageInfo);
		return "forward:/rent_company_list.jsp";
	}
	
	@RequestMapping("/find")
	public String findById(String id,Model model) {
		List<Company> companys = companyService.findCompanyById(id);
		model.addAttribute("company",companys);
		return "forward:/checkCompany.jsp";
	}
	
	@RequestMapping("/updateInput/{id}")
	public String updateInput(@PathVariable int id,Model model) {
		Company company = companyService.findCompanyId(id);
		model.addAttribute("company",company);
		return "forward:/rent_company_update.jsp";
	}

	@RequestMapping("/updateOutput")
	public String updateOutput(Company company) {
		companyService.updateCompanyById(company);
		return "redirect:/companny/findall.do";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteCompanyById(@PathVariable int id, Model model) {
		companyService.deleteCompanyById(id);
		return "redirect:/companny/findall.do";
	}
}
