package com.hy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hy.model.CarBrand;
import com.hy.model.Car_type;
import com.hy.service.ITypeService;

/**
 * ǰ�˿�������--ʵ�ֳ�ϵ��Ϣ����
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/type")
public class TypeController {

	@Autowired
	private ITypeService typeService;
	
	@RequestMapping("/add")
	public String addtype(Car_type type){
		typeService.addType(type);
		return "redirect:/type/findall.do";
	}
	@RequestMapping("/check")
	public String findCT(String inputvalue,Model model){
		List<Car_type> types = typeService.findCT(inputvalue);
		model.addAttribute("types", types);
		return "forward:/Check.jsp";
	}
	/*@RequestMapping("/updateUser/{id}")
	public String updateUser(@PathVariable int id){
		return null;
	}*/
	
	/**
	 * ��ѯ����
	 * @param model
*	 * @return
	 */
	@RequestMapping("/findall")
	public String findAll(Model model,@RequestParam(required=false,defaultValue="1",value="pn")int pn){
		PageHelper.startPage(pn, 6);
		List<Car_type> types = typeService.findAll();
		PageInfo<Car_type> pageInfo = new PageInfo<>(types,5);
		model.addAttribute("types", pageInfo);
		return "forward:/list.jsp";
	}
	
	/**
	 * ����type_id�������ҳ��
	 * @return
	 */
	@RequestMapping("/updateInput/{id}")
	public String updateInput(@PathVariable int id,Model model) {
		Car_type type = typeService.findCTById(id);
		model.addAttribute("type",type);
		return "forward:/updateType.jsp";
	}
	/**
	 * ����type_id�������ҳ��
	 * @return
	 */
	@RequestMapping("/updateOutput")
	public String updateOutput(Car_type type) {
		typeService.updateCTById(type);
		return "redirect:/type/findall.do";
	}
	@RequestMapping("/delete/{id}")
	public String deleteCTById(@PathVariable int id) {
		typeService.deleteCTById(id);
		return "redirect:/type/findall.do";
	}
	
}

