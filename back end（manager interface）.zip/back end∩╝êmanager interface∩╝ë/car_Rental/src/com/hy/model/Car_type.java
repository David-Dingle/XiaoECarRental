package com.hy.model;

import java.util.Date;
import java.util.List;

public class Car_type {
	
	int id;
	String brand_code;
	String serial_code;
	String serial_name;
	String create_date; 
	
	public Car_type() {
		
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand_code() {
		return brand_code;
	}

	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}

	public String getSerial_code() {
		return serial_code;
	}

	public void setSerial_code(String serial_code) {
		this.serial_code = serial_code;
	}

	public String getSerial_name() {
		return serial_name;
	}

	public void setSerial_name(String serial_name) {
		this.serial_name = serial_name;
	}

	public String getCreate_date() {
		return create_date;
	}

	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}

	
	
}
