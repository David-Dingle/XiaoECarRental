package com.hy.model;

import java.util.Date;

public class Holiday {
	int id;
	int lease_id;
	String holiday;
	int holiday_type;
	String create_date;
	
	public Holiday() {
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getLease_id() {
		return lease_id;
	}
	public void setLease_id(int lease_id) {
		this.lease_id = lease_id;
	}
	public int getHoliday_type() {
		return holiday_type;
	}
	public void setHoliday_type(int holiday_type) {
		this.holiday_type = holiday_type;
	}
	public String getHoliday() {
		return holiday;
	}
	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}
	
}
