package com.hy.model;

import java.sql.Timestamp;

public class Logging {
	private int id;
	private String user_host;
	private String user_ip;
	private String user_uri;
	private String user_method;
	private Timestamp create_date;
	
	public Logging() {
	
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUser_host() {
		return user_host;
	}

	public void setUser_host(String user_host) {
		this.user_host = user_host;
	}

	public String getUser_ip() {
		return user_ip;
	}

	public void setUser_ip(String user_ip) {
		this.user_ip = user_ip;
	}

	public String getUser_uri() {
		return user_uri;
	}

	public void setUser_uri(String user_uri) {
		this.user_uri = user_uri;
	}

	public String getUser_method() {
		return user_method;
	}

	public void setUser_method(String user_method) {
		this.user_method = user_method;
	}

	public Timestamp getCreate_date() {
		return create_date;
	}

	public void setCreate_date(Timestamp create_date) {
		this.create_date = create_date;
	}

	@Override
	public String toString() {
		return "Logging [id=" + id + ", user_host=" + user_host + ", user_ip=" + user_ip + ", user_uri=" + user_uri
				+ ", use_method=" + user_method + ", create_date=" + create_date + "]";
	}
	
	
}
