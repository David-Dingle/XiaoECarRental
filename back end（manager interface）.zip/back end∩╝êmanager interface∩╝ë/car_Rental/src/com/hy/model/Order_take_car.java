package com.hy.model;

import java.util.Date;

public class Order_take_car {
	int id;
	String user_real_name;
	String user_phone;
	Date take_date;
	Date return_date;
	Order_car order_car;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getUser_real_name() {
		return user_real_name;
	}
	public void setUser_real_name(String user_real_name) {
		this.user_real_name = user_real_name;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	public Date getTake_date() {
		return take_date;
	}
	public void setTake_date(Date take_date) {
		this.take_date = take_date;
	}
	public Date getReturn_date() {
		return return_date;
	}
	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}
	public Order_car getOrder_car() {
		return order_car;
	}
	public void setOrder_car(Order_car order_car) {
		this.order_car = order_car;
	}
	
}
