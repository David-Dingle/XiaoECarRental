package com.hy.model;

import java.util.Date;

public class CarBrand {
	int id;
	String code;
	String name;
	String picture;
	String url;
	Date date;
	String py;
	public CarBrand(int id, String code, String name, String picture, String url, Date date, String py) {
		this.id = id;
		this.code = code;
		this.name = name;
		this.picture = picture;
		this.url = url;
		this.date = date;
		this.py = py;
	}
	public CarBrand() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPicture() {
		return picture;
	}
	public void setPicture(String picture) {
		this.picture = picture;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getPy() {
		return py;
	}
	public void setPy(String py) {
		this.py = py;
	}
	
}
