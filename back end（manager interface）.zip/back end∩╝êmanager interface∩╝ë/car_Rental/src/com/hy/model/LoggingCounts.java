package com.hy.model;

public class LoggingCounts {
	private String months;
	private String peoples;
	
	public LoggingCounts() {
		
	}
	public LoggingCounts(String months, String peoples) {
		this.months = months;
		this.peoples = peoples;
	}
	public String getMonths() {
		return months;
	}
	public void setMonths(String months) {
		this.months = months;
	}
	public String getPeoples() {
		return peoples;
	}
	public void setPeoples(String peoples) {
		this.peoples = peoples;
	}
	
	
}
