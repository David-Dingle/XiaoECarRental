package com.hy.service;

import java.util.List;
import java.util.Map;

import com.hy.model.Logging;
import com.hy.model.LoggingCounts;


public interface ILoggingservice {

	public void insertLogging(Logging log);
	public List<LoggingCounts> selectfromLogging();
}
