package com.hy.service;

import java.util.List;

import com.hy.model.Company;

public interface ICompanyService {
	public void addCompany(Company company);
	
	
	public List<Company> findCompanyById(String id);
	
	
	public void updateCompanyById(Company company);
	
	
	public void deleteCompanyById(int id);
	
	public Company findCompanyId(int id);
	
	
	public List<Company> findAll();
}
