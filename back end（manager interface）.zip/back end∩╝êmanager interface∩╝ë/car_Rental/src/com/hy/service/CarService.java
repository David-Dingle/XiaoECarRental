package com.hy.service;

import java.util.List;

import com.hy.model.Car;


public interface CarService {

	public void addCar(Car car);

	public void deleteCar(int id);

	public void updateCar(Car car);

	public List<Car> checkCarById(int id);

	public List<Car> searchCar(String keyword);

	public List<Car> checkAllCar();
}
