package com.hy.service;

import java.util.List;

import com.hy.model.Order;
import com.hy.model.Order_car;

public interface IOrderService {
	public List<Order> findAllOrder();
	
	public List<Order_car> findOrder(int id);
	
	public void deleteOrderById(int id);
	
	public List<Order> searchMember(int pay_state,String inputvalue);
	
	public void upPay_stateById(int id);
	
	public void upTake_stateById(int id);
}
