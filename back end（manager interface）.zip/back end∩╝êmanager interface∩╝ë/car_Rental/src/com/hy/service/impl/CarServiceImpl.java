package com.hy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CarMapper;
import com.hy.model.Car;
import com.hy.service.CarService;

@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private CarMapper mapper;
	
	@Transactional
	@Override
	public void addCar(Car car) {
		mapper.addCar(car);
	}

	@Override
	public void deleteCar(int id) {
		mapper.deleteCar(id);
	}

	@Override
	public void updateCar(Car car) {
		mapper.updateCar(car);
	}

	@Override
	public List<Car> checkCarById(int id) {
		return mapper.checkCarById(id);
	}

	@Override
	public List<Car> searchCar(String keyword) {
		return mapper.searchCar(keyword);
	}

	@Override
	public List<Car> checkAllCar() {
		return mapper.checkAllCar();
	}

}
