package com.hy.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.HolidayMapper;
import com.hy.model.Company;
import com.hy.model.Holiday;
import com.hy.service.IHolidayService;

@Service
public class HolidayServicelmpl implements IHolidayService{
	@Autowired
	private HolidayMapper holidayMapper ;
	@Transactional
	@Override
public void addHoliday(Holiday holiday) {
		Date time = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		String ntime=dateFormat.format(time);
		holiday.setCreate_date(ntime);
		holidayMapper.addHoliday(holiday);
	}
	
	
	/**
	 * ���ļ�����Ϣ
	 */
	@Override
	public void updateHoliday(Holiday holiday) {
		holidayMapper.updateHoliday(holiday);
	}
	
	/**
	 * ɾ��������Ϣ
	 */
	@Override
	public void deleteHolidayById(int id) {
		holidayMapper.deleteHolidayById(id);
	}
	/**
	 * ��ȫ��������Ϣ
	 */
	@Override
	public List<Holiday> findAll(){
		/*List<Holiday> Holidays=holidayMapper.findAll();
		Iterator<Holiday> iterator = Holidays.iterator();
		while(iterator.hasNext()) {
			Holiday holiday = (Holiday)iterator.next();
			holiday.getHoliday()
		}*/
		return holidayMapper.findAll();
	}
	/**
	 * ͨ��ID�Ҽ�����Ϣ
	 */
	@Override
	public Holiday findHolidayById(int id){
		return holidayMapper.findHolidayById(id);
	}
	@Override
	public List<Company> findallConame() {
		return holidayMapper.findallConame();
	}
}
