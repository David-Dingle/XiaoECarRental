package com.hy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CarBrandMapper;
import com.hy.model.CarBrand;
import com.hy.service.CarBrandService;

@Service
public class CarBrandServiceImpl implements CarBrandService {
	
	@Autowired
	private CarBrandMapper mapper;
	
	@Transactional
	@Override
	public void addCarBrand(CarBrand cb) {
		mapper.addCarBrand(cb);
	}
	
	@Override
	public void deleteCarBrand(int id) {
		mapper.deleteCarBrand(id);
	}
	
	@Override
	public void updateCarBrand(CarBrand cb) {
		mapper.updateCarBrand(cb);
	}
	
	@Override
	public List<CarBrand> checkCarBrandById(int id){
		return mapper.checkCarBrandById(id);
	}
	
	@Override
	public List<CarBrand> checkAllCarBrand(){
		return mapper.checkAllCarBrand();
	}
	
	@Override
	public List<CarBrand> searchCarBrand(String keyword){
		return mapper.searchCarBrand(keyword);
	}
}
