package com.hy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.OrderMapper;
import com.hy.model.Order;
import com.hy.model.Order_car;
import com.hy.service.IOrderService;

@Service
public class OrderServicelmpl implements IOrderService{
		@Autowired
		private OrderMapper orderMapper ;
		@Transactional
		@Override
		public List<Order> findAllOrder() {
			return orderMapper.findAllOrder();
		}
		@Override
		public List<Order_car> findOrder(int id){
			return orderMapper.findOrder(id);
		}
		@Override
		public void deleteOrderById(int id) {
			orderMapper.deleteOrderById(id);
		}
		@Override
		public List<Order> searchMember(int pay_state,String inputvalue){
			return orderMapper.searchMember(pay_state,inputvalue);
		}
		@Override
		public void upPay_stateById(int id) {
			orderMapper.upPay_stateById(id);
		}
		@Override
		public void upTake_stateById(int id) {
			orderMapper.upTake_stateById(id);
		}
}
