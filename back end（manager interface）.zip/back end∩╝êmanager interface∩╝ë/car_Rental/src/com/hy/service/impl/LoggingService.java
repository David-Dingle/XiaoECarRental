package com.hy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hy.mapper.LoggingMapper;
import com.hy.model.Logging;
import com.hy.model.LoggingCounts;
import com.hy.service.ILoggingservice;


@Service
public class LoggingService implements ILoggingservice {
	@Autowired
	LoggingMapper loggingmap;
	
	@Override
	public void insertLogging(Logging log) {
		loggingmap.insertLogging(log);
	}

	@Override
	public List<LoggingCounts> selectfromLogging() {
		return loggingmap.selectfromLogging();
	}


}
