package com.hy.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.TypeMapper;
import com.hy.model.Car_type;
import com.hy.service.ITypeService;

@Service
public class TypeServicelmpl implements ITypeService {
	@Autowired
	private TypeMapper typemapper ;
	@Transactional
	@Override
    public void addType(Car_type Car_type) {
		Date time = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		String ntime=dateFormat.format(time);
		Car_type.setCreate_date(ntime);
    	typemapper.addType(Car_type);
    }
	@Override
	public List<Car_type> findCT(String inputvalue) {
		return typemapper.findCT(inputvalue);
	}
	@Override
	public void updateCTById(Car_type Car_type) {
		typemapper.updateCTById(Car_type);
	}
	
	@Override
	public void deleteCTById(int id) {
		typemapper.deleteCTById(id);
	}
	
	@Override
	public List<Car_type> findAll(){
		return typemapper.findAll();
	}
	@Override
	public Car_type findCTById(int id) {
		return typemapper.findCTById(id);
	}
}
