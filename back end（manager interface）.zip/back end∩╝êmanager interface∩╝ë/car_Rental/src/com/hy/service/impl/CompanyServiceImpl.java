package com.hy.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hy.mapper.CompanyMapper;
import com.hy.model.Company;
import com.hy.service.ICompanyService;

@Service
public class CompanyServiceImpl implements ICompanyService{
	@Autowired
	private CompanyMapper companyMapper;

	@Transactional
	@Override
	public void addCompany(Company company) {
		// TODO Auto-generated method stub
		companyMapper.addCompany(company);
	}

	@Override
	public List<Company> findCompanyById(String id) {
		// TODO Auto-generated method stub
		return companyMapper.findCompanyById(id);
	}

	@Override
	public void updateCompanyById(Company company) {
		// TODO Auto-generated method stub
		companyMapper.updateCompanyById(company);
	}

	@Override
	public void deleteCompanyById(int id) {
		// TODO Auto-generated method stub
		companyMapper.deleteCompanyById(id);
	}

	@Override
	public List<Company> findAll() {
		// TODO Auto-generated method stub
		return companyMapper.findAllCompany();
	}
	
	@Override
	public Company findCompanyId(int id) {
		return companyMapper.findCompanyId(id);
	}
}
