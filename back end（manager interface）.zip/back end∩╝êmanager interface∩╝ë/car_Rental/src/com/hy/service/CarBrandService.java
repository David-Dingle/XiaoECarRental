package com.hy.service;

import java.util.List;

import com.hy.model.CarBrand;

/*
 * ҵ���߼���
 */
public interface CarBrandService {
	/*
	 * ����
	 */
	public void addCarBrand(CarBrand cb);
	
	/*
	 * ɾ��
	 */
	public void deleteCarBrand(int id);
	
	/*
	 * �޸�
	 */
	public void updateCarBrand(CarBrand cb);
	
	/*
	 * ��ѯ
	 */
	public List<CarBrand> checkCarBrandById(int id);
	
	public List<CarBrand> searchCarBrand(String keyword);
	/*
	 * ȫ����ӡ
	 */
	public List<CarBrand> checkAllCarBrand();
}
