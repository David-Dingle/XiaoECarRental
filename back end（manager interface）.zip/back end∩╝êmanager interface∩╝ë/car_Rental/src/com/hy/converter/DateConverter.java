package com.hy.converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;

public class DateConverter implements Converter<String,Date>{

	// ���ڵ�ģ�� ���磺yyyy-MM-dd
	private String pattern;
	
	
	
	public String getPattern() {
		return pattern;
	}



	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public Date convert(String source) {
		Date date = null;
		// ��ʽ�� 1999-9-9��
		try{
			SimpleDateFormat sf = new SimpleDateFormat(pattern);
			date = sf.parse(source);
		} 
		catch (ParseException e){
			e.printStackTrace();
		}
		return date;
	}
}
